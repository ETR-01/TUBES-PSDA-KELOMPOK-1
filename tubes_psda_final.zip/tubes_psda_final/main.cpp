#include "mainwindow.h"
#include <QApplication>
#include <QFont>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // Gunakan style Fusion agar tampilan konsisten di semua platform
    a.setStyle("Fusion");

    // Set font default aplikasi
    QFont font("Segoe UI", 10);
    a.setFont(font);

    // ---- Global Stylesheet ----
    a.setStyleSheet(R"(
        QMainWindow {
            background-color: #0f172a;
        }
        QWidget {
            background-color: #0f172a;
            color: #e2e8f0;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        QScrollBar:vertical {
            background: #1e293b;
            width: 8px;
            border-radius: 4px;
        }
        QScrollBar::handle:vertical {
            background: #38bdf8;
            border-radius: 4px;
            min-height: 20px;
        }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
            height: 0px;
        }
        QScrollBar:horizontal {
            background: #1e293b;
            height: 8px;
            border-radius: 4px;
        }
        QScrollBar::handle:horizontal {
            background: #38bdf8;
            border-radius: 4px;
        }
        QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
            width: 0px;
        }
        QToolTip {
            background-color: #1e293b;
            color: #e2e8f0;
            border: 1px solid #38bdf8;
            padding: 4px 8px;
            border-radius: 4px;
        }
    )");

    // ---- Tampilkan halaman Login terlebih dahulu ----
    // LoginWindow ditampilkan sebagai layar pertama.
    // Setelah login berhasil, signal loginBerhasil dikirim dan
    // MainWindow akan dibuat sesuai role (Admin / User).

    LoginWindow *loginWin = new LoginWindow();
    loginWin->setWindowTitle("🏥  SI Rumah Sakit — Login");
    loginWin->show();

    // Pointer ke MainWindow (dibuat saat login sukses)
    MainWindow *mainWin = nullptr;

    // Hubungkan signal loginBerhasil ke lambda yang membuat MainWindow
    QObject::connect(loginWin, &LoginWindow::loginBerhasil,
                     [&](RoleLogin role, const QString &namaUser) {
                         // Buat MainWindow dengan role dan nama pengguna
                         mainWin = new MainWindow(role, namaUser);
                         mainWin->show();

                         // Tutup jendela login
                         loginWin->close();
                         loginWin->deleteLater();
                     });

    return a.exec();
}