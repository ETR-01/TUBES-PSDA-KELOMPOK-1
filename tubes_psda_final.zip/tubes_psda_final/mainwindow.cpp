#include "mainwindow.h"

// ============================================================
//  STYLING CONSTANTS — digunakan di seluruh aplikasi
// ============================================================

static const QString STYLE_MAIN = R"(
    QWidget#centralW {
        background-color: #0f172a;
    }
)";

static const QString STYLE_SIDEBAR = R"(
    QWidget#sidebar {
        background-color: #0a0f1e;
        border-right: 1px solid #1e293b;
    }
)";

static const QString STYLE_NAV_BTN = R"(
    QPushButton {
        background-color: transparent;
        color: #94a3b8;
        border: none;
        border-radius: 10px;
        padding: 12px 16px;
        text-align: left;
        font-size: 13px;
        font-weight: 500;
    }
    QPushButton:hover {
        background-color: #1e293b;
        color: #e2e8f0;
    }
    QPushButton:pressed {
        background-color: #0ea5e9;
        color: #ffffff;
    }
)";

static const QString STYLE_NAV_BTN_ACTIVE = R"(
    QPushButton {
        background-color: #0c4a6e;
        color: #38bdf8;
        border: none;
        border-left: 3px solid #38bdf8;
        border-radius: 10px;
        padding: 12px 16px;
        text-align: left;
        font-size: 13px;
        font-weight: 600;
    }
)";

static const QString STYLE_INPUT = R"(
    QLineEdit, QComboBox, QDateEdit, QSpinBox, QTextEdit {
        background-color: #1e293b;
        color: #e2e8f0;
        border: 1px solid #334155;
        border-radius: 8px;
        padding: 8px 12px;
        font-size: 13px;
        selection-background-color: #0ea5e9;
    }
    QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QSpinBox:focus {
        border: 1px solid #38bdf8;
        background-color: #1e3a5f;
    }
    QComboBox::drop-down {
        border: none;
        padding-right: 8px;
    }
    QComboBox::down-arrow {
        image: none;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 6px solid #38bdf8;
        width: 0; height: 0;
    }
    QComboBox QAbstractItemView {
        background-color: #1e293b;
        color: #e2e8f0;
        border: 1px solid #334155;
        selection-background-color: #0ea5e9;
        outline: none;
    }
    QDateEdit::up-button, QDateEdit::down-button,
    QSpinBox::up-button, QSpinBox::down-button {
        background-color: #334155;
        border-radius: 3px;
        width: 16px;
    }
    QDateEdit::up-button:hover, QDateEdit::down-button:hover,
    QSpinBox::up-button:hover, QSpinBox::down-button:hover {
        background-color: #0ea5e9;
    }
)";

static const QString STYLE_TABLE = R"(
    QTableWidget {
        background-color: #1e293b;
        alternate-background-color: #162032;
        color: #e2e8f0;
        gridline-color: #2d3f55;
        border: 1px solid #334155;
        border-radius: 10px;
        font-size: 12px;
    }
    QTableWidget::item {
        padding: 8px 10px;
        border: none;
    }
    QTableWidget::item:selected {
        background-color: #0c4a6e;
        color: #38bdf8;
    }
    QHeaderView::section {
        background-color: #0f172a;
        color: #38bdf8;
        padding: 10px 10px;
        border: none;
        border-bottom: 2px solid #0ea5e9;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    QTableWidget::item:hover {
        background-color: #243654;
    }
    QTableCornerButton::section {
        background-color: #0f172a;
        border: none;
    }
)";

static const QString STYLE_BTN_PRIMARY = R"(
    QPushButton {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 #0ea5e9, stop:1 #0284c7);
        color: #ffffff;
        border: none;
        border-radius: 8px;
        padding: 9px 20px;
        font-size: 13px;
        font-weight: 600;
    }
    QPushButton:hover {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 #38bdf8, stop:1 #0ea5e9);
    }
    QPushButton:pressed {
        background-color: #0369a1;
    }
    QPushButton:disabled {
        background-color: #334155;
        color: #64748b;
    }
)";

static const QString STYLE_BTN_DANGER = R"(
    QPushButton {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 #ef4444, stop:1 #dc2626);
        color: #ffffff;
        border: none;
        border-radius: 8px;
        padding: 9px 20px;
        font-size: 13px;
        font-weight: 600;
    }
    QPushButton:hover {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 #f87171, stop:1 #ef4444);
    }
    QPushButton:pressed { background-color: #b91c1c; }
)";

static const QString STYLE_BTN_WARNING = R"(
    QPushButton {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 #f59e0b, stop:1 #d97706);
        color: #ffffff;
        border: none;
        border-radius: 8px;
        padding: 9px 20px;
        font-size: 13px;
        font-weight: 600;
    }
    QPushButton:hover {
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
            stop:0 #fbbf24, stop:1 #f59e0b);
    }
    QPushButton:pressed { background-color: #b45309; }
)";

static const QString STYLE_BTN_LOGOUT = R"(
    QPushButton {
        background-color: transparent;
        color: #ef4444;
        border: 1px solid #ef4444;
        border-radius: 8px;
        padding: 8px 16px;
        font-size: 12px;
        font-weight: 600;
        text-align: left;
    }
    QPushButton:hover {
        background-color: #ef444420;
        color: #f87171;
        border-color: #f87171;
    }
)";

static const QString STYLE_GROUPBOX = R"(
    QGroupBox {
        color: #38bdf8;
        font-weight: 700;
        font-size: 13px;
        border: 1px solid #1e3a5f;
        border-radius: 10px;
        margin-top: 10px;
        padding-top: 10px;
    }
    QGroupBox::title {
        subcontrol-origin: margin;
        left: 12px;
        top: -6px;
        background-color: #0f172a;
        padding: 0 6px;
    }
)";

static const QString STYLE_DIALOG = R"(
    QDialog {
        background-color: #0f172a;
        color: #e2e8f0;
    }
    QLabel {
        color: #94a3b8;
        font-size: 12px;
        font-weight: 500;
    }
)";

// ============================================================
//  LOGIN WINDOW — Halaman pertama yang ditampilkan
// ============================================================

LoginWindow::LoginWindow(QWidget *parent)
    : QWidget(parent)
{
    setFixedSize(480, 580);
    setWindowTitle("Login — SI Rumah Sakit");
    setupUI();
}

/**
 * @brief Mengembalikan path file JSON yang sama dengan yang dipakai MainWindow.
 *        Dibuat static agar bisa dipanggil tanpa instance MainWindow.
 */
QString LoginWindow::pathDataFile()
{
    QString dir = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    QDir().mkpath(dir);
    return dir + "/data.json";
}

/**
 * @brief Membaca data pasien dari file JSON dan mengubahnya menjadi
 *        QVector<AkunUser> untuk keperluan validasi login.
 *
 *        Username = nama pasien (diubah ke lowercase, spasi → tidak dihiraukan)
 *        Password = tanggal lahir pasien
 *
 *        Jika file belum ada (belum ada data), kembalikan list kosong.
 */
QVector<AkunUser> LoginWindow::bacaAkunUserDariJSON() const
{
    QVector<AkunUser> hasil;

    QFile file(pathDataFile());
    if (!file.exists() || !file.open(QIODevice::ReadOnly))
        return hasil;   // Belum ada data — list kosong

    QJsonParseError err;
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &err);
    file.close();

    if (err.error != QJsonParseError::NoError || !doc.isObject())
        return hasil;

    QJsonObject root = doc.object();
    for (const QJsonValue &v : root["pasien"].toArray()) {
        QJsonObject o = v.toObject();
        AkunUser akun;
        akun.namaLengkap  = o["nama"].toString();
        // Username = nama lengkap diubah ke lowercase
        akun.username     = akun.namaLengkap.toLower();
        akun.tanggalLahir = QDate::fromString(o["tanggalLahir"].toString(), "yyyy-MM-dd");
        if (!akun.namaLengkap.isEmpty() && akun.tanggalLahir.isValid())
            hasil.append(akun);
    }
    return hasil;
}

/**
 * @brief Membangun tampilan halaman login:
 *        - Pilihan role: Admin / User (radio button)
 *        - Form berbeda untuk masing-masing role (QStackedWidget)
 */
void LoginWindow::setupUI()
{
    // Latar belakang gradien
    setStyleSheet(R"(
        QWidget {
            background-color: #0f172a;
            color: #e2e8f0;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
    )");

    QVBoxLayout *mainLay = new QVBoxLayout(this);
    mainLay->setContentsMargins(50, 40, 50, 40);
    mainLay->setSpacing(20);

    // ---- Logo & Judul ----
    QLabel *ikon = new QLabel("🏥");
    ikon->setAlignment(Qt::AlignCenter);
    ikon->setStyleSheet("font-size: 52px; background: transparent;");

    QLabel *judulApp = new QLabel("SI Rumah Sakit");
    judulApp->setAlignment(Qt::AlignCenter);
    judulApp->setStyleSheet(
        "color: #38bdf8; font-size: 24px; font-weight: 800; "
        "letter-spacing: 1px; background: transparent;");

    QLabel *subjudul = new QLabel("Sistem Informasi Pasien & Rekam Medis");
    subjudul->setAlignment(Qt::AlignCenter);
    subjudul->setStyleSheet("color: #475569; font-size: 12px; background: transparent;");

    mainLay->addWidget(ikon);
    mainLay->addWidget(judulApp);
    mainLay->addWidget(subjudul);

    // ---- Garis Pemisah ----
    QFrame *garis = new QFrame;
    garis->setFrameShape(QFrame::HLine);
    garis->setStyleSheet("color: #1e293b; margin: 4px 0;");
    mainLay->addWidget(garis);

    // ---- Pilihan Role ----
    QLabel *lblPilihRole = new QLabel("Masuk sebagai:");
    lblPilihRole->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 600;");
    mainLay->addWidget(lblPilihRole);

    QHBoxLayout *radioLay = new QHBoxLayout;
    radioLay->setSpacing(12);

    // Kotak pemilihan Admin
    QWidget *boxAdmin = new QWidget;
    boxAdmin->setStyleSheet(R"(
        QWidget {
            background-color: #1e293b;
            border: 2px solid #334155;
            border-radius: 10px;
            padding: 4px;
        }
        QWidget:hover { border-color: #0ea5e9; }
    )");
    QHBoxLayout *boxAdminLay = new QHBoxLayout(boxAdmin);
    boxAdminLay->setContentsMargins(12, 10, 12, 10);
    radioAdmin = new QRadioButton("🛡️  Admin");
    radioAdmin->setStyleSheet(
        "QRadioButton { color: #e2e8f0; font-size: 13px; font-weight: 600; background: transparent; }"
        "QRadioButton::indicator { width: 16px; height: 16px; border-radius: 8px; border: 2px solid #334155; }"
        "QRadioButton::indicator:checked { background-color: #0ea5e9; border-color: #0ea5e9; }");
    boxAdminLay->addWidget(radioAdmin);

    // Kotak pemilihan User
    QWidget *boxUser = new QWidget;
    boxUser->setStyleSheet(R"(
        QWidget {
            background-color: #1e293b;
            border: 2px solid #334155;
            border-radius: 10px;
            padding: 4px;
        }
        QWidget:hover { border-color: #0ea5e9; }
    )");
    QHBoxLayout *boxUserLay = new QHBoxLayout(boxUser);
    boxUserLay->setContentsMargins(12, 10, 12, 10);
    radioUser = new QRadioButton("👤  User / Pasien");
    radioUser->setStyleSheet(
        "QRadioButton { color: #e2e8f0; font-size: 13px; font-weight: 600; background: transparent; }"
        "QRadioButton::indicator { width: 16px; height: 16px; border-radius: 8px; border: 2px solid #334155; }"
        "QRadioButton::indicator:checked { background-color: #0ea5e9; border-color: #0ea5e9; }");
    boxUserLay->addWidget(radioUser);

    radioAdmin->setChecked(true);   // Default: Admin

    radioLay->addWidget(boxAdmin);
    radioLay->addWidget(boxUser);
    mainLay->addLayout(radioLay);

    // ---- Form Login (berganti sesuai pilihan radio) ----
    stackForm = new QStackedWidget;
    setupFormAdmin();   // Index 0
    setupFormUser();    // Index 1
    stackForm->addWidget(formAdmin);
    stackForm->addWidget(formUser);
    mainLay->addWidget(stackForm, 1);

    // Hubungkan radio button ke slot ganti tampilan form
    connect(radioAdmin, &QRadioButton::toggled, this, &LoginWindow::gantiBtnLogin);
    connect(radioUser,  &QRadioButton::toggled, this, &LoginWindow::gantiBtnLogin);

    mainLay->addStretch();

    // ---- Catatan kecil versi ----
    QLabel *keterangan = new QLabel("v1.0  |  Hak akses admin: CRUD  |  User: Read-only");
    keterangan->setAlignment(Qt::AlignCenter);
    keterangan->setStyleSheet("color: #334155; font-size: 10px; background: transparent;");
    mainLay->addWidget(keterangan);
}

/**
 * @brief Membangun form login untuk Admin:
 *        - Input: Username + Password
 */
void LoginWindow::setupFormAdmin()
{
    formAdmin = new QWidget;
    QVBoxLayout *lay = new QVBoxLayout(formAdmin);
    lay->setContentsMargins(0, 0, 0, 0);
    lay->setSpacing(10);

    // Label info kredensial admin (untuk demo)
    QLabel *infoAdmin = new QLabel("🔐  Username: admin  |  Password: admin123");
    infoAdmin->setAlignment(Qt::AlignCenter);
    infoAdmin->setStyleSheet(
        "background-color: #0c4a6e; color: #38bdf8; font-size: 11px; "
        "border: 1px solid #1e3a5f; border-radius: 6px; padding: 6px 10px;");
    lay->addWidget(infoAdmin);

    // Input Username Admin
    QLabel *lblUser = new QLabel("Username Admin");
    lblUser->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 600;");
    lay->addWidget(lblUser);

    inputAdminUsername = new QLineEdit;
    inputAdminUsername->setPlaceholderText("Masukkan username admin...");
    inputAdminUsername->setStyleSheet(STYLE_INPUT);
    inputAdminUsername->setMinimumHeight(42);
    lay->addWidget(inputAdminUsername);

    // Input Password Admin
    QLabel *lblPass = new QLabel("Password");
    lblPass->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 600;");
    lay->addWidget(lblPass);

    inputAdminPassword = new QLineEdit;
    inputAdminPassword->setPlaceholderText("Masukkan password...");
    inputAdminPassword->setEchoMode(QLineEdit::Password);  // Sembunyikan karakter
    inputAdminPassword->setStyleSheet(STYLE_INPUT);
    inputAdminPassword->setMinimumHeight(42);
    lay->addWidget(inputAdminPassword);

    // Tombol Login Admin
    QPushButton *btnLogin = new QPushButton("🛡️  Masuk sebagai Admin");
    btnLogin->setStyleSheet(STYLE_BTN_PRIMARY);
    btnLogin->setMinimumHeight(44);
    btnLogin->setCursor(Qt::PointingHandCursor);
    lay->addWidget(btnLogin);

    // Koneksi tombol & Enter key
    connect(btnLogin,           &QPushButton::clicked,
            this, &LoginWindow::prosesLoginAdmin);
    connect(inputAdminPassword, &QLineEdit::returnPressed,
            this, &LoginWindow::prosesLoginAdmin);
    connect(inputAdminUsername, &QLineEdit::returnPressed,
            inputAdminPassword, QOverload<>::of(&QWidget::setFocus));
}

/**
 * @brief Membangun form login untuk User:
 *        - Input: Username + Tanggal Lahir (sebagai kunci)
 */
void LoginWindow::setupFormUser()
{
    formUser = new QWidget;
    QVBoxLayout *lay = new QVBoxLayout(formUser);
    lay->setContentsMargins(0, 0, 0, 0);
    lay->setSpacing(10);

    // Label info akun user
    QLabel *infoUser = new QLabel(
        "👤  Username = nama lengkap pasien (huruf kecil)\n"
        "🔑  Kunci masuk = tanggal lahir pasien");
    infoUser->setAlignment(Qt::AlignCenter);
    infoUser->setWordWrap(true);
    infoUser->setStyleSheet(
        "background-color: #14532d20; color: #4ade80; font-size: 10px; "
        "border: 1px solid #14532d; border-radius: 6px; padding: 6px 10px;");
    lay->addWidget(infoUser);

    // Input Username User
    QLabel *lblUser = new QLabel("Username  (nama lengkap pasien, huruf kecil)");
    lblUser->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 600;");
    lay->addWidget(lblUser);

    inputUserUsername = new QLineEdit;
    inputUserUsername->setPlaceholderText("contoh: budi santoso");
    inputUserUsername->setStyleSheet(STYLE_INPUT);
    inputUserUsername->setMinimumHeight(42);
    lay->addWidget(inputUserUsername);

    // Input Tanggal Lahir sebagai kunci masuk
    QLabel *lblTgl = new QLabel("Tanggal Lahir  (sebagai kunci masuk)");
    lblTgl->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 600;");
    lay->addWidget(lblTgl);

    inputUserTanggalLahir = new QDateEdit(QDate(2000, 1, 1));
    inputUserTanggalLahir->setCalendarPopup(true);
    inputUserTanggalLahir->setDisplayFormat("dd/MM/yyyy");
    inputUserTanggalLahir->setStyleSheet(STYLE_INPUT);
    inputUserTanggalLahir->setMinimumHeight(42);
    lay->addWidget(inputUserTanggalLahir);

    // Tombol Login User
    QPushButton *btnLogin = new QPushButton("👤  Masuk sebagai User");
    btnLogin->setStyleSheet(R"(
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 #059669, stop:1 #047857);
            color: #ffffff;
            border: none;
            border-radius: 8px;
            padding: 9px 20px;
            font-size: 13px;
            font-weight: 600;
        }
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 #10b981, stop:1 #059669);
        }
        QPushButton:pressed { background-color: #065f46; }
    )");
    btnLogin->setMinimumHeight(44);
    btnLogin->setCursor(Qt::PointingHandCursor);
    lay->addWidget(btnLogin);

    connect(btnLogin, &QPushButton::clicked, this, &LoginWindow::prosesLoginUser);
}

/**
 * @brief Slot: mengganti form tampilan sesuai pilihan radio Admin/User
 */
void LoginWindow::gantiBtnLogin()
{
    if (radioAdmin->isChecked())
        stackForm->setCurrentWidget(formAdmin);
    else
        stackForm->setCurrentWidget(formUser);
}

/**
 * @brief Slot: validasi login Admin.
 *        Username & password dibandingkan dengan kredensial universal.
 */
void LoginWindow::prosesLoginAdmin()
{
    QString usernameInput = inputAdminUsername->text().trimmed();
    QString passwordInput = inputAdminPassword->text();

    if (usernameInput.isEmpty() || passwordInput.isEmpty()) {
        QMessageBox::warning(this, "Login Gagal", "Username dan password tidak boleh kosong!");
        return;
    }

    // Validasi kredensial admin universal
    if (usernameInput == ADMIN_USERNAME && passwordInput == ADMIN_PASSWORD) {
        // Login berhasil — kirim signal dengan role Admin
        emit loginBerhasil(RoleLogin::Admin, "Administrator");
    } else {
        QMessageBox::critical(this, "Login Gagal",
                              "Username atau password Admin salah!\n\n"
                              "Pastikan username: admin\n"
                              "Password: admin123");
        inputAdminPassword->clear();
        inputAdminPassword->setFocus();
    }
}

/**
 * @brief Slot: validasi login User.
 *        Membaca data pasien dari file JSON saat login,
 *        lalu mencari nama pasien yang cocok (Linear Search)
 *        dan memverifikasi tanggal lahir sebagai kunci masuk.
 */
void LoginWindow::prosesLoginUser()
{
    QString usernameInput = inputUserUsername->text().trimmed().toLower();
    QDate   tglLahirInput = inputUserTanggalLahir->date();

    if (usernameInput.isEmpty()) {
        QMessageBox::warning(this, "Login Gagal", "Username tidak boleh kosong!");
        return;
    }

    // Baca data pasien terkini dari file JSON
    QVector<AkunUser> daftarAkunUser = bacaAkunUserDariJSON();

    if (daftarAkunUser.isEmpty()) {
        QMessageBox::warning(this, "Belum Ada Data",
                             "Belum ada data pasien terdaftar.\n"
                             "Silakan minta Administrator untuk menambahkan data pasien terlebih dahulu.");
        return;
    }

    // Linear Search: cocokkan username dengan nama pasien
    bool    ditemukan      = false;
    QString namaLengkapUser;

    for (int i = 0; i < daftarAkunUser.size(); ++i) {
        if (daftarAkunUser[i].username == usernameInput) {
            // Username cocok — verifikasi tanggal lahir
            if (daftarAkunUser[i].tanggalLahir == tglLahirInput) {
                ditemukan       = true;
                namaLengkapUser = daftarAkunUser[i].namaLengkap;
            } else {
                QMessageBox::critical(this, "Login Gagal",
                                      "Tanggal lahir tidak sesuai!\n"
                                      "Periksa kembali tanggal lahir Anda.");
                return;
            }
            break;
        }
    }

    if (ditemukan) {
        emit loginBerhasil(RoleLogin::User, namaLengkapUser);
    } else {
        QMessageBox::critical(this, "Login Gagal",
                              QString("Username '%1' tidak ditemukan!\n\n"
                                      "💡 Tips: gunakan nama lengkap pasien\n"
                                      "   (huruf kecil, contoh: \"budi santoso\")")
                                  .arg(usernameInput));
        inputUserUsername->setFocus();
        inputUserUsername->selectAll();
    }
}

// ============================================================
//  MAINWINDOW — Constructor / Destructor
// ============================================================

/**
 * @brief Konstruktor MainWindow.
 * @param role      Role pengguna (Admin atau User)
 * @param namaUser  Nama pengguna yang akan ditampilkan di sidebar
 */
MainWindow::MainWindow(RoleLogin role, const QString &namaUser, QWidget *parent)
    : QMainWindow(parent),
    nextPasienId(1), nextDokterId(1), nextObatId(1),
    activeNavBtn(nullptr),
    roleAktif(role),
    namaUserAktif(namaUser)
{
    setWindowTitle("🏥  Sistem Informasi Rumah Sakit");
    setMinimumSize(1100, 700);
    resize(1280, 780);

    // Muat data tersimpan; jika belum ada, gunakan data contoh
    muatData();
    if (dataPasien.isEmpty() && dataDokter.isEmpty() && dataObat.isEmpty())
        inisialisasiDataContoh();

    setupUI();

    // Timer jam real-time
    clockTimer = new QTimer(this);
    connect(clockTimer, &QTimer::timeout, this, &MainWindow::updateClock);
    clockTimer->start(1000);
    updateClock();

    showDashboard();
}

MainWindow::~MainWindow() {}

// ============================================================
//  PERSISTENSI DATA — JSON
// ============================================================

QString MainWindow::pathDataFile() const
{
    QString dir = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    QDir().mkpath(dir);
    return dir + "/data.json";
}

void MainWindow::simpanData()
{
    QJsonObject root;

    // ---- Serialisasi Pasien ----
    QJsonArray arrPasien;
    for (const Pasien &p : dataPasien) {
        QJsonObject o;
        o["id"]            = p.id;
        o["nama"]          = p.nama;
        o["jenisKelamin"]  = p.jenisKelamin;
        o["umur"]          = p.umur;
        o["tanggalLahir"]  = p.tanggalLahir.toString("yyyy-MM-dd");
        o["noTelepon"]     = p.noTelepon;
        o["alamat"]        = p.alamat;
        o["golonganDarah"] = p.golonganDarah;
        o["diagnosa"]      = p.diagnosa;
        o["dokter"]        = p.dokter;
        o["ruangan"]       = p.ruangan;
        o["tanggalMasuk"]  = p.tanggalMasuk.toString("yyyy-MM-dd");
        o["status"]        = p.status;
        arrPasien.append(o);
    }
    root["pasien"]       = arrPasien;
    root["nextPasienId"] = nextPasienId;

    // ---- Serialisasi Dokter ----
    QJsonArray arrDokter;
    for (const Dokter &d : dataDokter) {
        QJsonObject o;
        o["id"]           = d.id;
        o["nama"]         = d.nama;
        o["spesialisasi"] = d.spesialisasi;
        o["noTelepon"]    = d.noTelepon;
        o["jadwal"]       = d.jadwal;
        o["tersedia"]     = d.tersedia;
        arrDokter.append(o);
    }
    root["dokter"]       = arrDokter;
    root["nextDokterId"] = nextDokterId;

    // ---- Serialisasi Obat ----
    QJsonArray arrObat;
    for (const Obat &ob : dataObat) {
        QJsonObject o;
        o["id"]     = ob.id;
        o["nama"]   = ob.nama;
        o["jenis"]  = ob.jenis;
        o["stok"]   = ob.stok;
        o["satuan"] = ob.satuan;
        o["harga"]  = ob.harga;
        arrObat.append(o);
    }
    root["obat"]       = arrObat;
    root["nextObatId"] = nextObatId;

    QFile file(pathDataFile());
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        file.write(QJsonDocument(root).toJson(QJsonDocument::Indented));
        file.close();
    }
}

void MainWindow::muatData()
{
    QFile file(pathDataFile());
    if (!file.exists() || !file.open(QIODevice::ReadOnly))
        return;

    QJsonParseError err;
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll(), &err);
    file.close();

    if (err.error != QJsonParseError::NoError || !doc.isObject())
        return;

    QJsonObject root = doc.object();

    dataPasien.clear();
    for (const QJsonValue &v : root["pasien"].toArray()) {
        QJsonObject o = v.toObject();
        Pasien p;
        p.id            = o["id"].toInt();
        p.nama          = o["nama"].toString();
        p.jenisKelamin  = o["jenisKelamin"].toString();
        p.umur          = o["umur"].toInt();
        p.tanggalLahir  = QDate::fromString(o["tanggalLahir"].toString(), "yyyy-MM-dd");
        p.noTelepon     = o["noTelepon"].toString();
        p.alamat        = o["alamat"].toString();
        p.golonganDarah = o["golonganDarah"].toString();
        p.diagnosa      = o["diagnosa"].toString();
        p.dokter        = o["dokter"].toString();
        p.ruangan       = o["ruangan"].toString();
        p.tanggalMasuk  = QDate::fromString(o["tanggalMasuk"].toString(), "yyyy-MM-dd");
        p.status        = o["status"].toString();
        dataPasien.append(p);
    }
    nextPasienId = root["nextPasienId"].toInt(dataPasien.size() + 1);

    dataDokter.clear();
    for (const QJsonValue &v : root["dokter"].toArray()) {
        QJsonObject o = v.toObject();
        Dokter d;
        d.id           = o["id"].toInt();
        d.nama         = o["nama"].toString();
        d.spesialisasi = o["spesialisasi"].toString();
        d.noTelepon    = o["noTelepon"].toString();
        d.jadwal       = o["jadwal"].toString();
        d.tersedia     = o["tersedia"].toBool(true);
        dataDokter.append(d);
    }
    nextDokterId = root["nextDokterId"].toInt(dataDokter.size() + 1);

    dataObat.clear();
    for (const QJsonValue &v : root["obat"].toArray()) {
        QJsonObject o = v.toObject();
        Obat ob;
        ob.id    = o["id"].toInt();
        ob.nama  = o["nama"].toString();
        ob.jenis = o["jenis"].toString();
        ob.stok  = o["stok"].toInt();
        ob.satuan= o["satuan"].toString();
        ob.harga = o["harga"].toDouble();
        dataObat.append(ob);
    }
    nextObatId = root["nextObatId"].toInt(dataObat.size() + 1);
}

// ============================================================
//  INISIALISASI DATA CONTOH
// ============================================================

void MainWindow::inisialisasiDataContoh()
{
    QStringList namaList = {"Budi Santoso","Siti Rahayu","Ahmad Fauzi",
                            "Dewi Lestari","Rizky Pratama","Nur Indah",
                            "Hendra Wijaya","Fitri Handayani"};
    QStringList jkList   = {"Laki-laki","Perempuan","Laki-laki","Perempuan",
                          "Laki-laki","Perempuan","Laki-laki","Perempuan"};
    QStringList diagList = {"Demam Berdarah","Hipertensi","Diabetes Mellitus",
                            "Tifoid","Appendicitis","Anemia","Fraktur Tulang","Gastritis"};
    QStringList dokList  = {"dr. Andi","dr. Sari","dr. Budi","dr. Maya",
                           "dr. Andi","dr. Sari","dr. Budi","dr. Maya"};
    QStringList ruList   = {"Mawar 1","Melati 2","ICU","Cempaka 3",
                          "Bedah 1","Mawar 2","Ortopedi","Melati 1"};
    QStringList stList   = {"Rawat Inap","Rawat Jalan","Rawat Inap","Selesai",
                          "Rawat Inap","Rawat Jalan","Rawat Inap","Selesai"};
    QStringList golList  = {"A","B","O","AB","A","O","B","AB"};

    QList<QDate> tglLahirList = {
        QDate(1990, 5, 14), QDate(1985, 8, 22), QDate(1995, 3, 7),
        QDate(1988, 11, 30), QDate(2000, 1, 17), QDate(1993, 6, 25),
        QDate(1978, 9, 10), QDate(2002, 4, 5)
    };

    for (int i = 0; i < namaList.size(); ++i) {
        Pasien p;
        p.id            = nextPasienId++;
        p.nama          = namaList[i];
        p.jenisKelamin  = jkList[i];
        p.umur          = 20 + i * 5;
        p.tanggalLahir  = tglLahirList[i];
        p.noTelepon     = QString("0812%1%2%3%4").arg(i).arg(i+1).arg(i+2).arg(i+3);
        p.alamat        = QString("Jl. Contoh No. %1, Jakarta").arg(i+1);
        p.golonganDarah = golList[i];
        p.diagnosa      = diagList[i];
        p.dokter        = dokList[i];
        p.ruangan       = ruList[i];
        p.tanggalMasuk  = QDate::currentDate().addDays(-i*3);
        p.status        = stList[i];
        dataPasien.append(p);
    }

    struct DokterInfo { QString nama, spesialis, telepon, jadwal; };
    QVector<DokterInfo> dInfo = {
                                 {"dr. Andi Pratama, Sp.PD", "Penyakit Dalam",     "0811-0001", "Sen-Jum 08:00-14:00"},
                                 {"dr. Sari Dewi, Sp.OG",    "Obstetri Ginekologi", "0811-0002", "Sel-Sab 09:00-15:00"},
                                 {"dr. Budi Hartono, Sp.B",  "Bedah Umum",          "0811-0003", "Sen-Rab 07:00-13:00"},
                                 {"dr. Maya Kusuma, Sp.A",   "Anak",                "0811-0004", "Kam-Sab 10:00-16:00"},
                                 {"dr. Rudi Santoso, Sp.JP", "Jantung & Pembuluh",  "0811-0005", "Sen-Jum 08:00-14:00"},
                                 };
    for (auto &d : dInfo) {
        Dokter dk;
        dk.id           = nextDokterId++;
        dk.nama         = d.nama;
        dk.spesialisasi = d.spesialis;
        dk.noTelepon    = d.telepon;
        dk.jadwal       = d.jadwal;
        dk.tersedia     = true;
        dataDokter.append(dk);
    }

    struct ObatInfo { QString nama, jenis, satuan; int stok; double harga; };
    QVector<ObatInfo> oInfo = {
                               {"Paracetamol 500mg",  "Analgetik",     "Tablet", 500, 1500},
                               {"Amoxicillin 500mg",  "Antibiotik",    "Kapsul", 300, 3500},
                               {"Omeprazole 20mg",    "Antasida",      "Kapsul", 200, 5000},
                               {"Amlodipine 5mg",     "Antihipertensi","Tablet", 150, 4000},
                               {"Metformin 500mg",    "Antidiabetik",  "Tablet", 250, 2500},
                               {"Cetirizine 10mg",    "Antihistamin",  "Tablet", 400, 2000},
                               {"Ranitidine 150mg",   "Antasida",      "Tablet", 180, 1800},
                               {"Vitamin C 500mg",    "Vitamin",       "Tablet", 600, 1200},
                               };
    for (auto &o : oInfo) {
        Obat ob;
        ob.id    = nextObatId++;
        ob.nama  = o.nama;
        ob.jenis = o.jenis;
        ob.stok  = o.stok;
        ob.satuan= o.satuan;
        ob.harga = o.harga;
        dataObat.append(ob);
    }
}

// ============================================================
//  SETUP UI — Main layout
// ============================================================

void MainWindow::setupUI()
{
    centralWidget = new QWidget(this);
    centralWidget->setObjectName("centralW");
    centralWidget->setStyleSheet(STYLE_MAIN);
    setCentralWidget(centralWidget);

    mainLayout = new QHBoxLayout(centralWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(0);

    setupSidebar();

    stackedWidget = new QStackedWidget(this);
    stackedWidget->setStyleSheet("background-color: #0f172a;");
    mainLayout->addWidget(stackedWidget, 1);

    setupDashboardPage();
    setupPasienPage();
    setupDokterPage();
    setupObatPage();
    setupCariPage();

    statusBar()->setStyleSheet(
        "QStatusBar { background-color: #0a0f1e; color: #64748b; "
        "font-size: 11px; border-top: 1px solid #1e293b; }");
    statusBar()->showMessage("  🏥  Sistem Informasi Rumah Sakit  |  Siap digunakan");
}

// ============================================================
//  SETUP SIDEBAR
// ============================================================

void MainWindow::setupSidebar()
{
    sidebar = new QWidget(this);
    sidebar->setObjectName("sidebar");
    sidebar->setFixedWidth(220);
    sidebar->setStyleSheet(STYLE_SIDEBAR);

    sidebarLayout = new QVBoxLayout(sidebar);
    sidebarLayout->setContentsMargins(12, 20, 12, 20);
    sidebarLayout->setSpacing(4);

    // Logo
    QLabel *logo = new QLabel("🏥");
    logo->setAlignment(Qt::AlignCenter);
    logo->setStyleSheet("font-size: 36px; padding: 4px;");

    QLabel *appName = new QLabel("SI Rumah Sakit");
    appName->setAlignment(Qt::AlignCenter);
    appName->setStyleSheet(
        "color: #38bdf8; font-size: 15px; font-weight: 700; "
        "letter-spacing: 0.5px; padding-bottom: 4px;");

    // Tampilkan nama & role pengguna yang sedang login
    bool isAdmin = (roleAktif == RoleLogin::Admin);
    QString roleStr = isAdmin ? "🛡️ Administrator" : "👤 User";
    QString roleColor = isAdmin ? "#f59e0b" : "#4ade80";

    lblInfoUser = new QLabel(QString("%1\n%2").arg(namaUserAktif).arg(roleStr));
    lblInfoUser->setAlignment(Qt::AlignCenter);
    lblInfoUser->setWordWrap(true);
    lblInfoUser->setStyleSheet(QString(
                                   "background-color: #1e293b; color: %1; font-size: 11px; font-weight: 600; "
                                   "border-radius: 8px; padding: 6px 8px; margin: 4px 0;").arg(roleColor));

    QFrame *divider = new QFrame;
    divider->setFrameShape(QFrame::HLine);
    divider->setStyleSheet("color: #1e293b; margin: 8px 0;");

    sidebarLayout->addWidget(logo);
    sidebarLayout->addWidget(appName);
    sidebarLayout->addWidget(lblInfoUser);
    sidebarLayout->addWidget(divider);

    // Tombol navigasi
    btnDashboard = createNavButton("  📊  Dashboard", "");
    btnPasien    = createNavButton("  👤  Data Pasien", "");
    btnDokter    = createNavButton("  🩺  Data Dokter", "");
    btnObat      = createNavButton("  💊  Data Obat", "");
    btnCari      = createNavButton("  🔍  Pencarian", "");

    connect(btnDashboard, &QPushButton::clicked, this, &MainWindow::showDashboard);
    connect(btnPasien,    &QPushButton::clicked, this, &MainWindow::showPasienPage);
    connect(btnDokter,    &QPushButton::clicked, this, &MainWindow::showDokterPage);
    connect(btnObat,      &QPushButton::clicked, this, &MainWindow::showObatPage);
    connect(btnCari,      &QPushButton::clicked, this, &MainWindow::showCariPage);

    sidebarLayout->addWidget(btnDashboard);
    sidebarLayout->addWidget(btnPasien);
    sidebarLayout->addWidget(btnDokter);
    sidebarLayout->addWidget(btnObat);
    sidebarLayout->addWidget(btnCari);

    sidebarLayout->addStretch();

    // Tampilkan label hak akses
    QString aksesStr = isAdmin ? "Hak Akses: CRUD Penuh" : "Hak Akses: Hanya Lihat";
    QLabel *aksesLabel = new QLabel(aksesStr);
    aksesLabel->setAlignment(Qt::AlignCenter);
    aksesLabel->setStyleSheet(QString(
                                  "color: %1; font-size: 10px; background-color: transparent;")
                                  .arg(isAdmin ? "#f59e0b" : "#4ade80"));
    sidebarLayout->addWidget(aksesLabel);

    // Tombol Logout
    btnLogout = new QPushButton("  🚪  Logout");
    btnLogout->setStyleSheet(STYLE_BTN_LOGOUT);
    btnLogout->setMinimumHeight(38);
    btnLogout->setCursor(Qt::PointingHandCursor);
    connect(btnLogout, &QPushButton::clicked, this, &MainWindow::prosesLogout);
    sidebarLayout->addWidget(btnLogout);

    QLabel *verLabel = new QLabel("v1.0.0  •  SI Rumah Sakit");
    verLabel->setAlignment(Qt::AlignCenter);
    verLabel->setStyleSheet("color: #334155; font-size: 10px; margin-top: 4px;");
    sidebarLayout->addWidget(verLabel);

    mainLayout->addWidget(sidebar);
}

// ============================================================
//  SLOT: Logout — kembali ke halaman login
// ============================================================

void MainWindow::prosesLogout()
{
    auto ret = QMessageBox::question(this, "Konfirmasi Logout",
                                     "Apakah Anda yakin ingin keluar?",
                                     QMessageBox::Yes | QMessageBox::No);
    if (ret != QMessageBox::Yes) return;

    // Tampilkan kembali LoginWindow dan tutup MainWindow
    LoginWindow *loginWin = new LoginWindow();
    loginWin->setWindowTitle("🏥  SI Rumah Sakit — Login");

    // Referensi ke this agar bisa ditutup dari dalam lambda
    MainWindow *selfPtr = this;

    QObject::connect(loginWin, &LoginWindow::loginBerhasil,
                     [selfPtr, loginWin](RoleLogin role, const QString &namaUser) {
                         MainWindow *newMain = new MainWindow(role, namaUser);
                         newMain->show();
                         loginWin->close();
                         loginWin->deleteLater();
                         selfPtr->close();
                         selfPtr->deleteLater();
                     });

    loginWin->show();
    hide();  // Sembunyikan dulu agar tidak ada jeda kosong
}

// ============================================================
//  HELPER: Create Stat Card
// ============================================================

QWidget* MainWindow::createStatCard(const QString &title, const QString &value,
                                    const QString &icon, const QString &color)
{
    QWidget *card = new QWidget;
    card->setStyleSheet(QString(R"(
        QWidget {
            background-color: #1e293b;
            border-radius: 14px;
            border-left: 4px solid %1;
        }
    )").arg(color));
    card->setMinimumHeight(110);

    QVBoxLayout *lay = new QVBoxLayout(card);
    lay->setContentsMargins(16, 14, 16, 14);
    lay->setSpacing(6);

    QHBoxLayout *topRow = new QHBoxLayout;
    QLabel *iconLbl = new QLabel(icon);
    iconLbl->setStyleSheet("font-size: 28px; background: transparent; border: none;");

    QLabel *titleLbl = new QLabel(title);
    titleLbl->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 500; "
                            "background: transparent; border: none;");
    titleLbl->setWordWrap(true);

    topRow->addWidget(iconLbl);
    topRow->addWidget(titleLbl, 1);
    lay->addLayout(topRow);

    QLabel *valLbl = new QLabel(value);
    valLbl->setStyleSheet(QString("color: %1; font-size: 28px; font-weight: 800; "
                                  "background: transparent; border: none;").arg(color));
    lay->addWidget(valLbl);

    return card;
}

// ============================================================
//  HELPER: Create Nav Button
// ============================================================

QPushButton* MainWindow::createNavButton(const QString &text, const QString &)
{
    QPushButton *btn = new QPushButton(text);
    btn->setStyleSheet(STYLE_NAV_BTN);
    btn->setCursor(Qt::PointingHandCursor);
    btn->setMinimumHeight(44);
    return btn;
}

// ============================================================
//  HELPER: Set Active Nav Button
// ============================================================

void MainWindow::setActiveNavButton(QPushButton *btn)
{
    QList<QPushButton*> navBtns = {btnDashboard, btnPasien, btnDokter, btnObat, btnCari};
    for (auto *b : navBtns) b->setStyleSheet(STYLE_NAV_BTN);
    btn->setStyleSheet(STYLE_NAV_BTN_ACTIVE);
    activeNavBtn = btn;
}

// ============================================================
//  HELPER: Apply Table Style
// ============================================================

void MainWindow::applyTableStyle(QTableWidget *table)
{
    table->setStyleSheet(STYLE_TABLE);
    table->setAlternatingRowColors(true);
    table->setSelectionBehavior(QAbstractItemView::SelectRows);
    table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    table->horizontalHeader()->setStretchLastSection(true);
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    table->verticalHeader()->setVisible(false);
    table->verticalHeader()->setDefaultSectionSize(40);
    table->setShowGrid(false);
    table->setFocusPolicy(Qt::NoFocus);
    table->setSelectionMode(QAbstractItemView::SingleSelection);
}

// ============================================================
//  SETUP DASHBOARD PAGE
// ============================================================

void MainWindow::setupDashboardPage()
{
    pageDashboard = new QWidget;
    pageDashboard->setStyleSheet("background-color: #0f172a;");

    QVBoxLayout *lay = new QVBoxLayout(pageDashboard);
    lay->setContentsMargins(28, 24, 28, 24);
    lay->setSpacing(20);

    QHBoxLayout *headerLay = new QHBoxLayout;
    QLabel *title = new QLabel("Dashboard");
    title->setStyleSheet("color: #f1f5f9; font-size: 26px; font-weight: 800;");

    lblJamTanggal = new QLabel;
    lblJamTanggal->setStyleSheet("color: #475569; font-size: 13px;");
    lblJamTanggal->setAlignment(Qt::AlignRight | Qt::AlignVCenter);

    headerLay->addWidget(title);
    headerLay->addStretch();
    headerLay->addWidget(lblJamTanggal);
    lay->addLayout(headerLay);

    // Tampilkan pesan selamat datang sesuai role
    bool isAdmin = (roleAktif == RoleLogin::Admin);
    QLabel *sub = new QLabel(
        QString("Selamat datang, %1! (%2)")
            .arg(namaUserAktif)
            .arg(isAdmin ? "Anda memiliki akses penuh" : "Mode hanya-lihat"));
    sub->setStyleSheet(QString("color: %1; font-size: 13px; margin-top: -12px;")
                           .arg(isAdmin ? "#f59e0b" : "#4ade80"));
    lay->addWidget(sub);

    QGridLayout *grid = new QGridLayout;
    grid->setSpacing(14);

    auto *c1 = createStatCard("Total Pasien",       "0", "👤", "#38bdf8");
    auto *c2 = createStatCard("Rawat Inap",         "0", "🛏️",  "#818cf8");
    auto *c3 = createStatCard("Rawat Jalan",        "0", "🚶", "#34d399");
    auto *c4 = createStatCard("Total Dokter",       "0", "🩺", "#fb923c");
    auto *c5 = createStatCard("Stok Obat (jenis)",  "0", "💊", "#f472b6");

    auto findVal = [](QWidget *card) -> QLabel* {
        for (auto *lbl : card->findChildren<QLabel*>())
            if (lbl->styleSheet().contains("font-size: 28px"))
                return lbl;
        return nullptr;
    };
    lblTotalPasien      = findVal(c1);
    lblPasienRawatInap  = findVal(c2);
    lblPasienRawatJalan = findVal(c3);
    lblTotalDokter      = findVal(c4);
    lblTotalObat        = findVal(c5);

    grid->addWidget(c1, 0, 0);
    grid->addWidget(c2, 0, 1);
    grid->addWidget(c3, 0, 2);
    grid->addWidget(c4, 1, 0);
    grid->addWidget(c5, 1, 1);
    lay->addLayout(grid);

    QLabel *recentTitle = new QLabel("Pasien Terbaru");
    recentTitle->setStyleSheet("color: #e2e8f0; font-size: 16px; font-weight: 700; margin-top: 6px;");
    lay->addWidget(recentTitle);

    QTableWidget *recentTable = new QTableWidget;
    recentTable->setObjectName("recentTable");
    recentTable->setColumnCount(6);
    recentTable->setHorizontalHeaderLabels(
        {"ID","Nama Pasien","Diagnosa","Dokter","Ruangan","Status"});
    applyTableStyle(recentTable);
    recentTable->setMaximumHeight(220);
    lay->addWidget(recentTable, 1);

    lay->addStretch();
    stackedWidget->addWidget(pageDashboard);
}

// ============================================================
//  SETUP PASIEN PAGE
// ============================================================

void MainWindow::setupPasienPage()
{
    pagePasien = new QWidget;
    pagePasien->setStyleSheet("background-color: #0f172a;");

    QVBoxLayout *lay = new QVBoxLayout(pagePasien);
    lay->setContentsMargins(28, 24, 28, 24);
    lay->setSpacing(14);

    QLabel *title = new QLabel("Data Pasien");
    title->setStyleSheet("color: #f1f5f9; font-size: 22px; font-weight: 800;");
    lay->addWidget(title);

    QHBoxLayout *toolbar = new QHBoxLayout;

    inputCariPasienPage = new QLineEdit;
    inputCariPasienPage->setPlaceholderText("🔍  Cari pasien (nama, diagnosa, status)...");
    inputCariPasienPage->setStyleSheet(STYLE_INPUT);
    inputCariPasienPage->setMinimumHeight(38);
    inputCariPasienPage->setMaximumWidth(360);

    toolbar->addWidget(inputCariPasienPage);
    toolbar->addStretch();

    // Tombol CRUD hanya ditampilkan untuk Admin
    if (roleAktif == RoleLogin::Admin) {
        QPushButton *btnTambah = new QPushButton("➕  Tambah Pasien");
        btnTambah->setStyleSheet(STYLE_BTN_PRIMARY);
        btnTambah->setMinimumHeight(38);
        btnTambah->setCursor(Qt::PointingHandCursor);

        QPushButton *btnEdit = new QPushButton("✏️  Edit");
        btnEdit->setStyleSheet(STYLE_BTN_WARNING);
        btnEdit->setMinimumHeight(38);
        btnEdit->setCursor(Qt::PointingHandCursor);

        QPushButton *btnHapus = new QPushButton("🗑️  Hapus");
        btnHapus->setStyleSheet(STYLE_BTN_DANGER);
        btnHapus->setMinimumHeight(38);
        btnHapus->setCursor(Qt::PointingHandCursor);

        toolbar->addWidget(btnTambah);
        toolbar->addWidget(btnEdit);
        toolbar->addWidget(btnHapus);

        connect(btnTambah, &QPushButton::clicked, this, &MainWindow::tambahPasien);
        connect(btnEdit,   &QPushButton::clicked, this, &MainWindow::editPasien);
        connect(btnHapus,  &QPushButton::clicked, this, &MainWindow::hapusPasien);
    } else {
        // Tampilkan badge "Read Only" untuk User
        QLabel *readOnlyBadge = new QLabel("🔒  Mode Baca Saja");
        readOnlyBadge->setStyleSheet(
            "background-color: #14532d30; color: #4ade80; font-size: 11px; font-weight: 600; "
            "border: 1px solid #14532d; border-radius: 6px; padding: 6px 12px;");
        toolbar->addWidget(readOnlyBadge);
    }

    lay->addLayout(toolbar);

    tabelPasien = new QTableWidget;
    tabelPasien->setColumnCount(11);
    tabelPasien->setHorizontalHeaderLabels(
        {"ID","Nama","JK","Umur","Tgl. Lahir","No. HP","Diagnosa","Dokter","Ruangan","Tgl Masuk","Status"});
    applyTableStyle(tabelPasien);
    lay->addWidget(tabelPasien, 1);

    connect(inputCariPasienPage, &QLineEdit::textChanged, this, [this](const QString &kw){
        if (kw.isEmpty()) { refreshTabelPasien(); return; }
        QVector<int> hasil = linearSearchPasien(kw, "semua");
        tabelPasien->setRowCount(0);
        for (int idx : hasil) {
            const Pasien &p = dataPasien[idx];
            int row = tabelPasien->rowCount();
            tabelPasien->insertRow(row);
            tabelPasien->setItem(row,0,new QTableWidgetItem(QString::number(p.id)));
            tabelPasien->setItem(row,1,new QTableWidgetItem(p.nama));
            tabelPasien->setItem(row,2,new QTableWidgetItem(p.jenisKelamin));
            tabelPasien->setItem(row,3,new QTableWidgetItem(QString::number(p.umur)));
            tabelPasien->setItem(row,4,new QTableWidgetItem(p.tanggalLahir.isValid() ? p.tanggalLahir.toString("dd/MM/yyyy") : "-"));
            tabelPasien->setItem(row,5,new QTableWidgetItem(p.noTelepon));
            tabelPasien->setItem(row,6,new QTableWidgetItem(p.diagnosa));
            tabelPasien->setItem(row,7,new QTableWidgetItem(p.dokter));
            tabelPasien->setItem(row,8,new QTableWidgetItem(p.ruangan));
            tabelPasien->setItem(row,9,new QTableWidgetItem(p.tanggalMasuk.toString("dd/MM/yyyy")));
            QTableWidgetItem *si = new QTableWidgetItem(p.status);
            if (p.status == "Rawat Inap")       si->setForeground(QColor("#818cf8"));
            else if (p.status == "Rawat Jalan") si->setForeground(QColor("#34d399"));
            else                                si->setForeground(QColor("#f59e0b"));
            tabelPasien->setItem(row,10,si);
        }
    });

    stackedWidget->addWidget(pagePasien);
}

// ============================================================
//  SETUP DOKTER PAGE
// ============================================================

void MainWindow::setupDokterPage()
{
    pageDokter = new QWidget;
    pageDokter->setStyleSheet("background-color: #0f172a;");

    QVBoxLayout *lay = new QVBoxLayout(pageDokter);
    lay->setContentsMargins(28, 24, 28, 24);
    lay->setSpacing(14);

    QLabel *title = new QLabel("Data Dokter");
    title->setStyleSheet("color: #f1f5f9; font-size: 22px; font-weight: 800;");
    lay->addWidget(title);

    QHBoxLayout *toolbar = new QHBoxLayout;

    inputCariDokterPage = new QLineEdit;
    inputCariDokterPage->setPlaceholderText("🔍  Cari dokter (nama, spesialisasi)...");
    inputCariDokterPage->setStyleSheet(STYLE_INPUT);
    inputCariDokterPage->setMinimumHeight(38);
    inputCariDokterPage->setMaximumWidth(360);

    toolbar->addWidget(inputCariDokterPage);
    toolbar->addStretch();

    if (roleAktif == RoleLogin::Admin) {
        QPushButton *btnTambah = new QPushButton("➕  Tambah Dokter");
        btnTambah->setStyleSheet(STYLE_BTN_PRIMARY);
        btnTambah->setMinimumHeight(38);
        btnTambah->setCursor(Qt::PointingHandCursor);

        QPushButton *btnEdit  = new QPushButton("✏️  Edit");
        btnEdit->setStyleSheet(STYLE_BTN_WARNING);
        btnEdit->setMinimumHeight(38);
        btnEdit->setCursor(Qt::PointingHandCursor);

        QPushButton *btnHapus = new QPushButton("🗑️  Hapus");
        btnHapus->setStyleSheet(STYLE_BTN_DANGER);
        btnHapus->setMinimumHeight(38);
        btnHapus->setCursor(Qt::PointingHandCursor);

        toolbar->addWidget(btnTambah);
        toolbar->addWidget(btnEdit);
        toolbar->addWidget(btnHapus);

        connect(btnTambah, &QPushButton::clicked, this, &MainWindow::tambahDokter);
        connect(btnEdit,   &QPushButton::clicked, this, &MainWindow::editDokter);
        connect(btnHapus,  &QPushButton::clicked, this, &MainWindow::hapusDokter);
    } else {
        QLabel *badge = new QLabel("🔒  Mode Baca Saja");
        badge->setStyleSheet(
            "background-color: #14532d30; color: #4ade80; font-size: 11px; font-weight: 600; "
            "border: 1px solid #14532d; border-radius: 6px; padding: 6px 12px;");
        toolbar->addWidget(badge);
    }

    lay->addLayout(toolbar);

    tabelDokter = new QTableWidget;
    tabelDokter->setColumnCount(6);
    tabelDokter->setHorizontalHeaderLabels(
        {"ID","Nama Dokter","Spesialisasi","No. Telepon","Jadwal Praktik","Status"});
    applyTableStyle(tabelDokter);
    lay->addWidget(tabelDokter, 1);

    connect(inputCariDokterPage, &QLineEdit::textChanged, this, [this](const QString &kw){
        if (kw.isEmpty()) { refreshTabelDokter(); return; }
        QVector<int> hasil = linearSearchDokter(kw, "semua");
        tabelDokter->setRowCount(0);
        for (int idx : hasil) {
            const Dokter &d = dataDokter[idx];
            int row = tabelDokter->rowCount();
            tabelDokter->insertRow(row);
            tabelDokter->setItem(row,0,new QTableWidgetItem(QString::number(d.id)));
            tabelDokter->setItem(row,1,new QTableWidgetItem(d.nama));
            tabelDokter->setItem(row,2,new QTableWidgetItem(d.spesialisasi));
            tabelDokter->setItem(row,3,new QTableWidgetItem(d.noTelepon));
            tabelDokter->setItem(row,4,new QTableWidgetItem(d.jadwal));
            QTableWidgetItem *av = new QTableWidgetItem(d.tersedia ? "✅ Tersedia" : "❌ Tidak Tersedia");
            av->setForeground(d.tersedia ? QColor("#34d399") : QColor("#ef4444"));
            tabelDokter->setItem(row,5,av);
        }
    });

    stackedWidget->addWidget(pageDokter);
}

// ============================================================
//  SETUP OBAT PAGE
// ============================================================

void MainWindow::setupObatPage()
{
    pageObat = new QWidget;
    pageObat->setStyleSheet("background-color: #0f172a;");

    QVBoxLayout *lay = new QVBoxLayout(pageObat);
    lay->setContentsMargins(28, 24, 28, 24);
    lay->setSpacing(14);

    QLabel *title = new QLabel("Data Obat");
    title->setStyleSheet("color: #f1f5f9; font-size: 22px; font-weight: 800;");
    lay->addWidget(title);

    QHBoxLayout *toolbar = new QHBoxLayout;

    inputCariObatPage = new QLineEdit;
    inputCariObatPage->setPlaceholderText("🔍  Cari obat (nama, jenis)...");
    inputCariObatPage->setStyleSheet(STYLE_INPUT);
    inputCariObatPage->setMinimumHeight(38);
    inputCariObatPage->setMaximumWidth(360);

    toolbar->addWidget(inputCariObatPage);
    toolbar->addStretch();

    if (roleAktif == RoleLogin::Admin) {
        QPushButton *btnTambah = new QPushButton("➕  Tambah Obat");
        btnTambah->setStyleSheet(STYLE_BTN_PRIMARY);
        btnTambah->setMinimumHeight(38);
        btnTambah->setCursor(Qt::PointingHandCursor);

        QPushButton *btnEdit  = new QPushButton("✏️  Edit");
        btnEdit->setStyleSheet(STYLE_BTN_WARNING);
        btnEdit->setMinimumHeight(38);
        btnEdit->setCursor(Qt::PointingHandCursor);

        QPushButton *btnHapus = new QPushButton("🗑️  Hapus");
        btnHapus->setStyleSheet(STYLE_BTN_DANGER);
        btnHapus->setMinimumHeight(38);
        btnHapus->setCursor(Qt::PointingHandCursor);

        toolbar->addWidget(btnTambah);
        toolbar->addWidget(btnEdit);
        toolbar->addWidget(btnHapus);

        connect(btnTambah, &QPushButton::clicked, this, &MainWindow::tambahObat);
        connect(btnEdit,   &QPushButton::clicked, this, &MainWindow::editObat);
        connect(btnHapus,  &QPushButton::clicked, this, &MainWindow::hapusObat);
    } else {
        QLabel *badge = new QLabel("🔒  Mode Baca Saja");
        badge->setStyleSheet(
            "background-color: #14532d30; color: #4ade80; font-size: 11px; font-weight: 600; "
            "border: 1px solid #14532d; border-radius: 6px; padding: 6px 12px;");
        toolbar->addWidget(badge);
    }

    lay->addLayout(toolbar);

    tabelObat = new QTableWidget;
    tabelObat->setColumnCount(6);
    tabelObat->setHorizontalHeaderLabels(
        {"ID","Nama Obat","Jenis","Stok","Satuan","Harga (Rp)"});
    applyTableStyle(tabelObat);
    lay->addWidget(tabelObat, 1);

    connect(inputCariObatPage, &QLineEdit::textChanged, this, [this](const QString &kw){
        if (kw.isEmpty()) { refreshTabelObat(); return; }
        QVector<int> hasil = linearSearchObat(kw, "semua");
        tabelObat->setRowCount(0);
        for (int idx : hasil) {
            const Obat &o = dataObat[idx];
            int row = tabelObat->rowCount();
            tabelObat->insertRow(row);
            tabelObat->setItem(row,0,new QTableWidgetItem(QString::number(o.id)));
            tabelObat->setItem(row,1,new QTableWidgetItem(o.nama));
            tabelObat->setItem(row,2,new QTableWidgetItem(o.jenis));
            QTableWidgetItem *stokItem = new QTableWidgetItem(QString::number(o.stok));
            if (o.stok < 50)       stokItem->setForeground(QColor("#ef4444"));
            else if (o.stok < 100) stokItem->setForeground(QColor("#f59e0b"));
            else                   stokItem->setForeground(QColor("#34d399"));
            tabelObat->setItem(row,3,stokItem);
            tabelObat->setItem(row,4,new QTableWidgetItem(o.satuan));
            tabelObat->setItem(row,5,new QTableWidgetItem(
                                           QString("Rp %1").arg(QString::number(o.harga,'f',0))));
        }
    });

    stackedWidget->addWidget(pageObat);
}

// ============================================================
//  SETUP CARI (SEARCH) PAGE
// ============================================================

void MainWindow::setupCariPage()
{
    pageCari = new QWidget;
    pageCari->setStyleSheet("background-color: #0f172a;");

    QVBoxLayout *lay = new QVBoxLayout(pageCari);
    lay->setContentsMargins(28, 24, 28, 24);
    lay->setSpacing(14);

    QLabel *title = new QLabel("Pencarian — Linear Search");
    title->setStyleSheet("color: #f1f5f9; font-size: 22px; font-weight: 800;");
    lay->addWidget(title);

    QLabel *desc = new QLabel(
        "Algoritma Linear Search menelusuri data satu per satu dari awal hingga akhir "
        "untuk menemukan data yang cocok dengan kata kunci yang dimasukkan.");
    desc->setStyleSheet("color: #64748b; font-size: 12px;");
    desc->setWordWrap(true);
    lay->addWidget(desc);

    QGroupBox *searchBox = new QGroupBox("Parameter Pencarian");
    searchBox->setStyleSheet(STYLE_GROUPBOX);
    QGridLayout *formGrid = new QGridLayout(searchBox);
    formGrid->setSpacing(10);
    formGrid->setContentsMargins(16, 20, 16, 16);

    auto lbl = [](const QString &t) {
        QLabel *l = new QLabel(t);
        l->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight:600;");
        return l;
    };

    comboSearchType  = new QComboBox;
    comboSearchType->addItems({"Pasien","Dokter","Obat"});
    comboSearchType->setStyleSheet(STYLE_INPUT);
    comboSearchType->setMinimumHeight(36);

    comboSearchField = new QComboBox;
    comboSearchField->addItems({"Semua Field","Nama","Diagnosa / Spesialisasi / Jenis","Status / Jadwal"});
    comboSearchField->setStyleSheet(STYLE_INPUT);
    comboSearchField->setMinimumHeight(36);

    inputSearchKeyword = new QLineEdit;
    inputSearchKeyword->setPlaceholderText("Masukkan kata kunci...");
    inputSearchKeyword->setStyleSheet(STYLE_INPUT);
    inputSearchKeyword->setMinimumHeight(36);

    QPushButton *btnCari = new QPushButton("  🔍  Cari Sekarang");
    btnCari->setStyleSheet(STYLE_BTN_PRIMARY);
    btnCari->setMinimumHeight(36);
    btnCari->setCursor(Qt::PointingHandCursor);

    formGrid->addWidget(lbl("Kategori Data:"),  0, 0);
    formGrid->addWidget(comboSearchType,        0, 1);
    formGrid->addWidget(lbl("Cari Berdasarkan:"),0,2);
    formGrid->addWidget(comboSearchField,       0, 3);
    formGrid->addWidget(lbl("Kata Kunci:"),     1, 0);
    formGrid->addWidget(inputSearchKeyword,     1, 1, 1, 2);
    formGrid->addWidget(btnCari,                1, 3);
    lay->addWidget(searchBox);

    lblStepInfo = new QLabel("Masukkan kata kunci dan tekan tombol Cari untuk memulai.");
    lblStepInfo->setStyleSheet(
        "background-color: #1e293b; color: #38bdf8; font-size: 12px; "
        "border: 1px solid #1e3a5f; border-radius: 8px; padding: 10px 14px;");
    lblStepInfo->setWordWrap(true);
    lay->addWidget(lblStepInfo);

    lblHasilInfo = new QLabel("Belum ada pencarian.");
    lblHasilInfo->setStyleSheet("color: #64748b; font-size: 12px; font-weight: 600;");
    lay->addWidget(lblHasilInfo);

    tabelHasilCari = new QTableWidget;
    tabelHasilCari->setColumnCount(5);
    tabelHasilCari->setHorizontalHeaderLabels({"ID","Field 1","Field 2","Field 3","Field 4"});
    applyTableStyle(tabelHasilCari);
    lay->addWidget(tabelHasilCari, 1);

    connect(comboSearchType,  QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &MainWindow::onSearchTypeChanged);
    connect(btnCari,          &QPushButton::clicked, this, [this](){
        int t = comboSearchType->currentIndex();
        if (t == 0)      cariPasien();
        else if (t == 1) cariDokter();
        else             cariObat();
    });
    connect(inputSearchKeyword, &QLineEdit::returnPressed, btnCari, &QPushButton::click);

    stackedWidget->addWidget(pageCari);
}

// ============================================================
//  NAVIGATION SLOTS
// ============================================================

void MainWindow::showDashboard()
{
    setActiveNavButton(btnDashboard);
    stackedWidget->setCurrentWidget(pageDashboard);
    updateDashboard();
}

void MainWindow::showPasienPage()
{
    setActiveNavButton(btnPasien);
    stackedWidget->setCurrentWidget(pagePasien);
    refreshTabelPasien();
}

void MainWindow::showDokterPage()
{
    setActiveNavButton(btnDokter);
    stackedWidget->setCurrentWidget(pageDokter);
    refreshTabelDokter();
}

void MainWindow::showObatPage()
{
    setActiveNavButton(btnObat);
    stackedWidget->setCurrentWidget(pageObat);
    refreshTabelObat();
}

void MainWindow::showCariPage()
{
    setActiveNavButton(btnCari);
    stackedWidget->setCurrentWidget(pageCari);
}

// ============================================================
//  UPDATE DASHBOARD
// ============================================================

void MainWindow::updateDashboard()
{
    int totalPasien = dataPasien.size();
    int rawatInap = 0, rawatJalan = 0;
    for (auto &p : dataPasien) {
        if (p.status == "Rawat Inap")  ++rawatInap;
        if (p.status == "Rawat Jalan") ++rawatJalan;
    }

    if (lblTotalPasien)      lblTotalPasien->setText(QString::number(totalPasien));
    if (lblPasienRawatInap)  lblPasienRawatInap->setText(QString::number(rawatInap));
    if (lblPasienRawatJalan) lblPasienRawatJalan->setText(QString::number(rawatJalan));
    if (lblTotalDokter)      lblTotalDokter->setText(QString::number(dataDokter.size()));
    if (lblTotalObat)        lblTotalObat->setText(QString::number(dataObat.size()));

    QTableWidget *rt = pageDashboard->findChild<QTableWidget*>("recentTable");
    if (!rt) return;
    rt->setRowCount(0);
    int count = qMin(5, dataPasien.size());
    for (int i = dataPasien.size()-1; i >= dataPasien.size()-count; --i) {
        const Pasien &p = dataPasien[i];
        int row = rt->rowCount();
        rt->insertRow(row);
        rt->setItem(row,0,new QTableWidgetItem(QString::number(p.id)));
        rt->setItem(row,1,new QTableWidgetItem(p.nama));
        rt->setItem(row,2,new QTableWidgetItem(p.diagnosa));
        rt->setItem(row,3,new QTableWidgetItem(p.dokter));
        rt->setItem(row,4,new QTableWidgetItem(p.ruangan));
        QTableWidgetItem *si = new QTableWidgetItem(p.status);
        if (p.status == "Rawat Inap")       si->setForeground(QColor("#818cf8"));
        else if (p.status == "Rawat Jalan") si->setForeground(QColor("#34d399"));
        else                                si->setForeground(QColor("#f59e0b"));
        rt->setItem(row,5,si);
    }
}

void MainWindow::updateClock()
{
    lblJamTanggal->setText(
        QDateTime::currentDateTime().toString("dddd, dd MMMM yyyy  |  hh:mm:ss"));
}

// ============================================================
//  REFRESH TABLES
// ============================================================

void MainWindow::refreshTabelPasien()
{
    tabelPasien->setRowCount(0);
    for (const Pasien &p : dataPasien) {
        int row = tabelPasien->rowCount();
        tabelPasien->insertRow(row);
        tabelPasien->setItem(row,0,new QTableWidgetItem(QString::number(p.id)));
        tabelPasien->setItem(row,1,new QTableWidgetItem(p.nama));
        tabelPasien->setItem(row,2,new QTableWidgetItem(p.jenisKelamin));
        tabelPasien->setItem(row,3,new QTableWidgetItem(QString::number(p.umur)));
        tabelPasien->setItem(row,4,new QTableWidgetItem(p.tanggalLahir.isValid() ? p.tanggalLahir.toString("dd/MM/yyyy") : "-"));
        tabelPasien->setItem(row,5,new QTableWidgetItem(p.noTelepon));
        tabelPasien->setItem(row,6,new QTableWidgetItem(p.diagnosa));
        tabelPasien->setItem(row,7,new QTableWidgetItem(p.dokter));
        tabelPasien->setItem(row,8,new QTableWidgetItem(p.ruangan));
        tabelPasien->setItem(row,9,new QTableWidgetItem(p.tanggalMasuk.toString("dd/MM/yyyy")));
        QTableWidgetItem *si = new QTableWidgetItem(p.status);
        if (p.status == "Rawat Inap")       si->setForeground(QColor("#818cf8"));
        else if (p.status == "Rawat Jalan") si->setForeground(QColor("#34d399"));
        else                                si->setForeground(QColor("#f59e0b"));
        tabelPasien->setItem(row,10,si);
    }
}

void MainWindow::refreshTabelDokter()
{
    tabelDokter->setRowCount(0);
    for (const Dokter &d : dataDokter) {
        int row = tabelDokter->rowCount();
        tabelDokter->insertRow(row);
        tabelDokter->setItem(row,0,new QTableWidgetItem(QString::number(d.id)));
        tabelDokter->setItem(row,1,new QTableWidgetItem(d.nama));
        tabelDokter->setItem(row,2,new QTableWidgetItem(d.spesialisasi));
        tabelDokter->setItem(row,3,new QTableWidgetItem(d.noTelepon));
        tabelDokter->setItem(row,4,new QTableWidgetItem(d.jadwal));
        QTableWidgetItem *av = new QTableWidgetItem(
            d.tersedia ? "✅ Tersedia" : "❌ Tidak Tersedia");
        av->setForeground(d.tersedia ? QColor("#34d399") : QColor("#ef4444"));
        tabelDokter->setItem(row,5,av);
    }
}

void MainWindow::refreshTabelObat()
{
    tabelObat->setRowCount(0);
    for (const Obat &o : dataObat) {
        int row = tabelObat->rowCount();
        tabelObat->insertRow(row);
        tabelObat->setItem(row,0,new QTableWidgetItem(QString::number(o.id)));
        tabelObat->setItem(row,1,new QTableWidgetItem(o.nama));
        tabelObat->setItem(row,2,new QTableWidgetItem(o.jenis));
        QTableWidgetItem *stokItem = new QTableWidgetItem(QString::number(o.stok));
        if (o.stok < 50)       stokItem->setForeground(QColor("#ef4444"));
        else if (o.stok < 100) stokItem->setForeground(QColor("#f59e0b"));
        else                   stokItem->setForeground(QColor("#34d399"));
        tabelObat->setItem(row,3,stokItem);
        tabelObat->setItem(row,4,new QTableWidgetItem(o.satuan));
        tabelObat->setItem(row,5,new QTableWidgetItem(
                                       QString("Rp %1").arg(QString::number(o.harga,'f',0))));
    }
}

// ============================================================
//  LINEAR SEARCH ALGORITHMS
// ============================================================

/**
 * @brief Linear Search pada array dataPasien.
 *        Kompleksitas waktu: O(n) — iterasi dari index 0 hingga n-1.
 * @param keyword Kata kunci pencarian
 * @param field   Field yang dicari ("nama", "diagnosa", "status", "semua", dst.)
 * @return QVector<int> berisi index-index data yang cocok
 */
QVector<int> MainWindow::linearSearchPasien(const QString &keyword, const QString &field)
{
    QVector<int> hasil;
    QString kw = keyword.toLower().trimmed();
    if (kw.isEmpty()) return hasil;

    // Iterasi linear: periksa setiap elemen satu per satu
    for (int i = 0; i < dataPasien.size(); ++i) {
        const Pasien &p = dataPasien[i];
        bool match = false;

        if (field == "nama"    || field == "semua") if (p.nama.toLower().contains(kw))      match = true;
        if (field == "diagnosa"|| field == "semua") if (p.diagnosa.toLower().contains(kw))  match = true;
        if (field == "status"  || field == "semua") if (p.status.toLower().contains(kw))    match = true;
        if (field == "dokter"  || field == "semua") if (p.dokter.toLower().contains(kw))    match = true;
        if (field == "ruangan" || field == "semua") if (p.ruangan.toLower().contains(kw))   match = true;
        if (field == "id"      || field == "semua") if (QString::number(p.id).contains(kw)) match = true;

        if (match) hasil.append(i);
    }
    return hasil;
}

/**
 * @brief Linear Search pada array dataDokter.
 */
QVector<int> MainWindow::linearSearchDokter(const QString &keyword, const QString &field)
{
    QVector<int> hasil;
    QString kw = keyword.toLower().trimmed();
    if (kw.isEmpty()) return hasil;

    for (int i = 0; i < dataDokter.size(); ++i) {
        const Dokter &d = dataDokter[i];
        bool match = false;

        if (field == "nama"        || field == "semua") if (d.nama.toLower().contains(kw))         match = true;
        if (field == "spesialisasi"|| field == "semua") if (d.spesialisasi.toLower().contains(kw)) match = true;
        if (field == "jadwal"      || field == "semua") if (d.jadwal.toLower().contains(kw))       match = true;
        if (field == "id"          || field == "semua") if (QString::number(d.id).contains(kw))    match = true;

        if (match) hasil.append(i);
    }
    return hasil;
}

/**
 * @brief Linear Search pada array dataObat.
 */
QVector<int> MainWindow::linearSearchObat(const QString &keyword, const QString &field)
{
    QVector<int> hasil;
    QString kw = keyword.toLower().trimmed();
    if (kw.isEmpty()) return hasil;

    for (int i = 0; i < dataObat.size(); ++i) {
        const Obat &o = dataObat[i];
        bool match = false;

        if (field == "nama"  || field == "semua") if (o.nama.toLower().contains(kw))   match = true;
        if (field == "jenis" || field == "semua") if (o.jenis.toLower().contains(kw))  match = true;
        if (field == "satuan"|| field == "semua") if (o.satuan.toLower().contains(kw)) match = true;
        if (field == "id"    || field == "semua") if (QString::number(o.id).contains(kw)) match = true;

        if (match) hasil.append(i);
    }
    return hasil;
}

// ============================================================
//  SEARCH PAGE SLOTS
// ============================================================

void MainWindow::onSearchTypeChanged(int index)
{
    comboSearchField->clear();
    if (index == 0)
        comboSearchField->addItems({"Semua Field","Nama","Diagnosa","Status","Dokter","Ruangan"});
    else if (index == 1)
        comboSearchField->addItems({"Semua Field","Nama","Spesialisasi","Jadwal"});
    else
        comboSearchField->addItems({"Semua Field","Nama","Jenis","Satuan"});

    tabelHasilCari->setRowCount(0);
    lblHasilInfo->setText("Belum ada pencarian.");
    lblStepInfo->setText("Pilih kategori dan masukkan kata kunci untuk mencari.");
}

void MainWindow::cariPasien()
{
    QString kw = inputSearchKeyword->text().trimmed();
    if (kw.isEmpty()) { QMessageBox::warning(this,"Peringatan","Masukkan kata kunci!"); return; }

    QString fieldMap;
    switch (comboSearchField->currentIndex()) {
    case 0: fieldMap = "semua";   break;
    case 1: fieldMap = "nama";    break;
    case 2: fieldMap = "diagnosa";break;
    case 3: fieldMap = "status";  break;
    case 4: fieldMap = "dokter";  break;
    case 5: fieldMap = "ruangan"; break;
    default:fieldMap = "semua";
    }

    lblStepInfo->setText(
        QString("🔄 Linear Search pada %1 data pasien...\n"
                "   Menelusuri tiap elemen dari index 0 hingga %2\n"
                "   Kata kunci: \"%3\" | Field: %4")
            .arg(dataPasien.size()).arg(dataPasien.size()-1)
            .arg(kw).arg(comboSearchField->currentText()));

    QVector<int> hasil = linearSearchPasien(kw, fieldMap);

    tabelHasilCari->setColumnCount(6);
    tabelHasilCari->setHorizontalHeaderLabels({"ID","Nama Pasien","Diagnosa","Dokter","Ruangan","Status"});
    tabelHasilCari->setRowCount(0);

    for (int idx : hasil) {
        const Pasien &p = dataPasien[idx];
        int row = tabelHasilCari->rowCount();
        tabelHasilCari->insertRow(row);
        tabelHasilCari->setItem(row,0,new QTableWidgetItem(QString::number(p.id)));
        tabelHasilCari->setItem(row,1,new QTableWidgetItem(p.nama));
        tabelHasilCari->setItem(row,2,new QTableWidgetItem(p.diagnosa));
        tabelHasilCari->setItem(row,3,new QTableWidgetItem(p.dokter));
        tabelHasilCari->setItem(row,4,new QTableWidgetItem(p.ruangan));
        QTableWidgetItem *si = new QTableWidgetItem(p.status);
        if (p.status == "Rawat Inap")       si->setForeground(QColor("#818cf8"));
        else if (p.status == "Rawat Jalan") si->setForeground(QColor("#34d399"));
        else                                si->setForeground(QColor("#f59e0b"));
        tabelHasilCari->setItem(row,5,si);
    }

    lblHasilInfo->setText(
        QString("✅  Ditemukan %1 dari %2 pasien  |  Kata kunci: \"%3\"")
            .arg(hasil.size()).arg(dataPasien.size()).arg(kw));
    lblStepInfo->setText(
        QString("✔  Linear Search selesai! Iterasi: %1  |  Cocok: %2  |  O(n)")
            .arg(dataPasien.size()).arg(hasil.size()));
    statusBar()->showMessage(QString("  Pencarian: \"%1\" → %2 hasil").arg(kw).arg(hasil.size()));
}

void MainWindow::cariDokter()
{
    QString kw = inputSearchKeyword->text().trimmed();
    if (kw.isEmpty()) { QMessageBox::warning(this,"Peringatan","Masukkan kata kunci!"); return; }

    QString fieldMap;
    switch (comboSearchField->currentIndex()) {
    case 0: fieldMap = "semua";        break;
    case 1: fieldMap = "nama";         break;
    case 2: fieldMap = "spesialisasi"; break;
    case 3: fieldMap = "jadwal";       break;
    default:fieldMap = "semua";
    }

    QVector<int> hasil = linearSearchDokter(kw, fieldMap);
    tabelHasilCari->setColumnCount(5);
    tabelHasilCari->setHorizontalHeaderLabels({"ID","Nama Dokter","Spesialisasi","Jadwal","Status"});
    tabelHasilCari->setRowCount(0);

    for (int idx : hasil) {
        const Dokter &d = dataDokter[idx];
        int row = tabelHasilCari->rowCount();
        tabelHasilCari->insertRow(row);
        tabelHasilCari->setItem(row,0,new QTableWidgetItem(QString::number(d.id)));
        tabelHasilCari->setItem(row,1,new QTableWidgetItem(d.nama));
        tabelHasilCari->setItem(row,2,new QTableWidgetItem(d.spesialisasi));
        tabelHasilCari->setItem(row,3,new QTableWidgetItem(d.jadwal));
        QTableWidgetItem *av = new QTableWidgetItem(d.tersedia ? "✅ Tersedia" : "❌ Tidak Tersedia");
        av->setForeground(d.tersedia ? QColor("#34d399") : QColor("#ef4444"));
        tabelHasilCari->setItem(row,4,av);
    }

    lblHasilInfo->setText(
        QString("✅  Ditemukan %1 dari %2 dokter  |  Kata kunci: \"%3\"")
            .arg(hasil.size()).arg(dataDokter.size()).arg(kw));
    lblStepInfo->setText(
        QString("✔  Linear Search selesai! Iterasi: %1  |  Cocok: %2  |  O(n)")
            .arg(dataDokter.size()).arg(hasil.size()));
}

void MainWindow::cariObat()
{
    QString kw = inputSearchKeyword->text().trimmed();
    if (kw.isEmpty()) { QMessageBox::warning(this,"Peringatan","Masukkan kata kunci!"); return; }

    QString fieldMap;
    switch (comboSearchField->currentIndex()) {
    case 0: fieldMap = "semua";  break;
    case 1: fieldMap = "nama";   break;
    case 2: fieldMap = "jenis";  break;
    case 3: fieldMap = "satuan"; break;
    default:fieldMap = "semua";
    }

    QVector<int> hasil = linearSearchObat(kw, fieldMap);
    tabelHasilCari->setColumnCount(5);
    tabelHasilCari->setHorizontalHeaderLabels({"ID","Nama Obat","Jenis","Stok","Harga (Rp)"});
    tabelHasilCari->setRowCount(0);

    for (int idx : hasil) {
        const Obat &o = dataObat[idx];
        int row = tabelHasilCari->rowCount();
        tabelHasilCari->insertRow(row);
        tabelHasilCari->setItem(row,0,new QTableWidgetItem(QString::number(o.id)));
        tabelHasilCari->setItem(row,1,new QTableWidgetItem(o.nama));
        tabelHasilCari->setItem(row,2,new QTableWidgetItem(o.jenis));
        tabelHasilCari->setItem(row,3,new QTableWidgetItem(QString::number(o.stok)));
        tabelHasilCari->setItem(row,4,new QTableWidgetItem(
                                            QString("Rp %1").arg(QString::number(o.harga,'f',0))));
    }

    lblHasilInfo->setText(
        QString("✅  Ditemukan %1 dari %2 obat  |  Kata kunci: \"%3\"")
            .arg(hasil.size()).arg(dataObat.size()).arg(kw));
    lblStepInfo->setText(
        QString("✔  Linear Search selesai! Iterasi: %1  |  Cocok: %2  |  O(n)")
            .arg(dataObat.size()).arg(hasil.size()));
}

// ============================================================
//  PASIEN CRUD
// ============================================================

void MainWindow::tambahPasien()
{
    // Guard: hanya Admin yang boleh tambah
    if (roleAktif != RoleLogin::Admin) return;

    DialogPasien dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        Pasien p = dlg.getPasien();
        p.id = nextPasienId++;
        dataPasien.append(p);       // Tambah ke array QVector
        refreshTabelPasien();
        simpanData();
        statusBar()->showMessage(QString("  ✅  Pasien \"%1\" berhasil ditambahkan").arg(p.nama));
    }
}

void MainWindow::editPasien()
{
    if (roleAktif != RoleLogin::Admin) return;

    int row = tabelPasien->currentRow();
    if (row < 0) { QMessageBox::information(this,"Info","Pilih pasien yang ingin diedit."); return; }

    int id = tabelPasien->item(row,0)->text().toInt();
    int dataIdx = -1;
    for (int i = 0; i < dataPasien.size(); ++i)
        if (dataPasien[i].id == id) { dataIdx = i; break; }
    if (dataIdx < 0) return;

    DialogPasien dlg(this, &dataPasien[dataIdx]);
    if (dlg.exec() == QDialog::Accepted) {
        Pasien p = dlg.getPasien();
        p.id = id;
        dataPasien[dataIdx] = p;    // Update elemen array
        refreshTabelPasien();
        simpanData();
        statusBar()->showMessage(QString("  ✏️  Pasien \"%1\" berhasil diperbarui").arg(p.nama));
    }
}

void MainWindow::hapusPasien()
{
    if (roleAktif != RoleLogin::Admin) return;

    int row = tabelPasien->currentRow();
    if (row < 0) { QMessageBox::information(this,"Info","Pilih pasien yang ingin dihapus."); return; }

    QString nama = tabelPasien->item(row,1)->text();
    int id       = tabelPasien->item(row,0)->text().toInt();

    if (QMessageBox::question(this,"Konfirmasi",
                              QString("Hapus data pasien \"%1\"?").arg(nama),
                              QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) return;

    for (int i = 0; i < dataPasien.size(); ++i)
        if (dataPasien[i].id == id) { dataPasien.remove(i); break; }  // Hapus dari array

    refreshTabelPasien();
    simpanData();
    statusBar()->showMessage(QString("  🗑️  Pasien \"%1\" berhasil dihapus").arg(nama));
}

// ============================================================
//  DOKTER CRUD
// ============================================================

void MainWindow::tambahDokter()
{
    if (roleAktif != RoleLogin::Admin) return;
    DialogDokter dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        Dokter d = dlg.getDokter();
        d.id = nextDokterId++;
        dataDokter.append(d);
        refreshTabelDokter();
        simpanData();
        statusBar()->showMessage(QString("  ✅  Dokter \"%1\" berhasil ditambahkan").arg(d.nama));
    }
}

void MainWindow::editDokter()
{
    if (roleAktif != RoleLogin::Admin) return;
    int row = tabelDokter->currentRow();
    if (row < 0) { QMessageBox::information(this,"Info","Pilih dokter yang ingin diedit."); return; }

    int id = tabelDokter->item(row,0)->text().toInt();
    int dataIdx = -1;
    for (int i = 0; i < dataDokter.size(); ++i)
        if (dataDokter[i].id == id) { dataIdx = i; break; }
    if (dataIdx < 0) return;

    DialogDokter dlg(this, &dataDokter[dataIdx]);
    if (dlg.exec() == QDialog::Accepted) {
        Dokter d = dlg.getDokter();
        d.id = id;
        dataDokter[dataIdx] = d;
        refreshTabelDokter();
        simpanData();
        statusBar()->showMessage(QString("  ✏️  Dokter \"%1\" berhasil diperbarui").arg(d.nama));
    }
}

void MainWindow::hapusDokter()
{
    if (roleAktif != RoleLogin::Admin) return;
    int row = tabelDokter->currentRow();
    if (row < 0) { QMessageBox::information(this,"Info","Pilih dokter yang ingin dihapus."); return; }

    QString nama = tabelDokter->item(row,1)->text();
    int id       = tabelDokter->item(row,0)->text().toInt();

    if (QMessageBox::question(this,"Konfirmasi",
                              QString("Hapus data dokter \"%1\"?").arg(nama),
                              QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) return;

    for (int i = 0; i < dataDokter.size(); ++i)
        if (dataDokter[i].id == id) { dataDokter.remove(i); break; }

    refreshTabelDokter();
    simpanData();
    statusBar()->showMessage(QString("  🗑️  Dokter \"%1\" berhasil dihapus").arg(nama));
}

// ============================================================
//  OBAT CRUD
// ============================================================

void MainWindow::tambahObat()
{
    if (roleAktif != RoleLogin::Admin) return;
    DialogObat dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        Obat o = dlg.getObat();
        o.id = nextObatId++;
        dataObat.append(o);
        refreshTabelObat();
        simpanData();
        statusBar()->showMessage(QString("  ✅  Obat \"%1\" berhasil ditambahkan").arg(o.nama));
    }
}

void MainWindow::editObat()
{
    if (roleAktif != RoleLogin::Admin) return;
    int row = tabelObat->currentRow();
    if (row < 0) { QMessageBox::information(this,"Info","Pilih obat yang ingin diedit."); return; }

    int id = tabelObat->item(row,0)->text().toInt();
    int dataIdx = -1;
    for (int i = 0; i < dataObat.size(); ++i)
        if (dataObat[i].id == id) { dataIdx = i; break; }
    if (dataIdx < 0) return;

    DialogObat dlg(this, &dataObat[dataIdx]);
    if (dlg.exec() == QDialog::Accepted) {
        Obat o = dlg.getObat();
        o.id = id;
        dataObat[dataIdx] = o;
        refreshTabelObat();
        simpanData();
        statusBar()->showMessage(QString("  ✏️  Obat \"%1\" berhasil diperbarui").arg(o.nama));
    }
}

void MainWindow::hapusObat()
{
    if (roleAktif != RoleLogin::Admin) return;
    int row = tabelObat->currentRow();
    if (row < 0) { QMessageBox::information(this,"Info","Pilih obat yang ingin dihapus."); return; }

    QString nama = tabelObat->item(row,1)->text();
    int id       = tabelObat->item(row,0)->text().toInt();

    if (QMessageBox::question(this,"Konfirmasi",
                              QString("Hapus data obat \"%1\"?").arg(nama),
                              QMessageBox::Yes | QMessageBox::No) != QMessageBox::Yes) return;

    for (int i = 0; i < dataObat.size(); ++i)
        if (dataObat[i].id == id) { dataObat.remove(i); break; }

    refreshTabelObat();
    simpanData();
    statusBar()->showMessage(QString("  🗑️  Obat \"%1\" berhasil dihapus").arg(nama));
}

// ============================================================
//  DIALOG PASIEN
// ============================================================

DialogPasien::DialogPasien(QWidget *parent, Pasien *pasien)
    : QDialog(parent), isEdit(pasien != nullptr), existingId(0)
{
    setStyleSheet(STYLE_DIALOG + STYLE_INPUT);
    setWindowTitle(isEdit ? "Edit Data Pasien" : "Tambah Pasien Baru");
    setMinimumWidth(480);
    setupUI();
    if (isEdit) { existingId = pasien->id; existingTanggal = pasien->tanggalMasuk; populateFields(*pasien); }
}

void DialogPasien::setupUI()
{
    QVBoxLayout *mainLay = new QVBoxLayout(this);
    mainLay->setContentsMargins(20,20,20,20);
    mainLay->setSpacing(12);

    QLabel *title = new QLabel(isEdit ? "✏️  Edit Data Pasien" : "➕  Tambah Pasien Baru");
    title->setStyleSheet("color: #38bdf8; font-size: 16px; font-weight: 700;");
    mainLay->addWidget(title);

    QFrame *div = new QFrame; div->setFrameShape(QFrame::HLine);
    div->setStyleSheet("color: #1e293b; margin: 2px 0 8px 0;");
    mainLay->addWidget(div);

    auto lbl = [](const QString &t) {
        QLabel *l = new QLabel(t);
        l->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight:600;");
        return l;
    };

    QFormLayout *form = new QFormLayout;
    form->setSpacing(10);
    form->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);

    inputNama     = new QLineEdit; inputNama->setPlaceholderText("Nama lengkap pasien"); inputNama->setMinimumHeight(34);
    comboJK       = new QComboBox; comboJK->addItems({"Laki-laki","Perempuan"}); comboJK->setMinimumHeight(34);
    spinUmur      = new QSpinBox;  spinUmur->setRange(0,150); spinUmur->setSuffix(" tahun"); spinUmur->setMinimumHeight(34);
    inputTanggalLahir = new QDateEdit(QDate(2000, 1, 1)); inputTanggalLahir->setCalendarPopup(true);
    inputTanggalLahir->setDisplayFormat("dd/MM/yyyy"); inputTanggalLahir->setMinimumHeight(34);
    inputTelepon  = new QLineEdit; inputTelepon->setPlaceholderText("08xx-xxxx-xxxx"); inputTelepon->setMinimumHeight(34);
    inputAlamat   = new QLineEdit; inputAlamat->setPlaceholderText("Alamat lengkap"); inputAlamat->setMinimumHeight(34);
    comboGoldar   = new QComboBox; comboGoldar->addItems({"A","B","O","AB"}); comboGoldar->setMinimumHeight(34);
    inputDiagnosa = new QLineEdit; inputDiagnosa->setPlaceholderText("Diagnosa dokter"); inputDiagnosa->setMinimumHeight(34);
    inputDokter   = new QLineEdit; inputDokter->setPlaceholderText("Nama dokter"); inputDokter->setMinimumHeight(34);
    inputRuangan  = new QLineEdit; inputRuangan->setPlaceholderText("Nama / nomor ruangan"); inputRuangan->setMinimumHeight(34);
    inputTanggal  = new QDateEdit(QDate::currentDate()); inputTanggal->setCalendarPopup(true);
    inputTanggal->setDisplayFormat("dd/MM/yyyy"); inputTanggal->setMinimumHeight(34);
    comboStatus   = new QComboBox; comboStatus->addItems({"Rawat Inap","Rawat Jalan","Selesai"}); comboStatus->setMinimumHeight(34);

    form->addRow(lbl("Nama Pasien :"),   inputNama);
    form->addRow(lbl("Jenis Kelamin :"), comboJK);
    form->addRow(lbl("Umur :"),          spinUmur);
    form->addRow(lbl("Tgl. Lahir :"),    inputTanggalLahir);
    form->addRow(lbl("No. Telepon :"),   inputTelepon);
    form->addRow(lbl("Alamat :"),        inputAlamat);
    form->addRow(lbl("Gol. Darah :"),    comboGoldar);
    form->addRow(lbl("Diagnosa :"),      inputDiagnosa);
    form->addRow(lbl("Dokter :"),        inputDokter);
    form->addRow(lbl("Ruangan :"),       inputRuangan);
    form->addRow(lbl("Tgl Masuk :"),     inputTanggal);
    form->addRow(lbl("Status :"),        comboStatus);
    mainLay->addLayout(form);

    QHBoxLayout *btnRow = new QHBoxLayout;
    btnRow->addStretch();
    QPushButton *btnBatal  = new QPushButton("Batal");
    QPushButton *btnSimpan = new QPushButton(isEdit ? "💾  Simpan" : "➕  Tambahkan");
    btnBatal->setStyleSheet(
        "QPushButton { background-color: #334155; color: #e2e8f0; border: none; "
        "border-radius: 8px; padding: 9px 20px; font-size: 13px; }"
        "QPushButton:hover { background-color: #475569; }");
    btnSimpan->setStyleSheet(STYLE_BTN_PRIMARY);
    btnBatal->setMinimumHeight(36); btnSimpan->setMinimumHeight(36);
    btnBatal->setCursor(Qt::PointingHandCursor); btnSimpan->setCursor(Qt::PointingHandCursor);

    connect(btnBatal,  &QPushButton::clicked, this, &QDialog::reject);
    connect(btnSimpan, &QPushButton::clicked, this, [this](){
        if (inputNama->text().trimmed().isEmpty()) {
            QMessageBox::warning(this,"Peringatan","Nama pasien tidak boleh kosong!");
            return;
        }
        accept();
    });
    btnRow->addWidget(btnBatal);
    btnRow->addWidget(btnSimpan);
    mainLay->addLayout(btnRow);
}

void DialogPasien::populateFields(const Pasien &p)
{
    inputNama->setText(p.nama);
    comboJK->setCurrentText(p.jenisKelamin);
    spinUmur->setValue(p.umur);
    inputTanggalLahir->setDate(p.tanggalLahir.isValid() ? p.tanggalLahir : QDate(2000, 1, 1));
    inputTelepon->setText(p.noTelepon);
    inputAlamat->setText(p.alamat);
    comboGoldar->setCurrentText(p.golonganDarah);
    inputDiagnosa->setText(p.diagnosa);
    inputDokter->setText(p.dokter);
    inputRuangan->setText(p.ruangan);
    inputTanggal->setDate(p.tanggalMasuk);
    comboStatus->setCurrentText(p.status);
}

Pasien DialogPasien::getPasien() const
{
    Pasien p;
    p.id            = existingId;
    p.nama          = inputNama->text().trimmed();
    p.jenisKelamin  = comboJK->currentText();
    p.umur          = spinUmur->value();
    p.tanggalLahir  = inputTanggalLahir->date();
    p.noTelepon     = inputTelepon->text().trimmed();
    p.alamat        = inputAlamat->text().trimmed();
    p.golonganDarah = comboGoldar->currentText();
    p.diagnosa      = inputDiagnosa->text().trimmed();
    p.dokter        = inputDokter->text().trimmed();
    p.ruangan       = inputRuangan->text().trimmed();
    p.tanggalMasuk  = inputTanggal->date();
    p.status        = comboStatus->currentText();
    return p;
}

// ============================================================
//  DIALOG DOKTER
// ============================================================

DialogDokter::DialogDokter(QWidget *parent, Dokter *dokter)
    : QDialog(parent), isEdit(dokter != nullptr), existingId(0)
{
    setStyleSheet(STYLE_DIALOG + STYLE_INPUT);
    setWindowTitle(isEdit ? "Edit Data Dokter" : "Tambah Dokter Baru");
    setMinimumWidth(420);
    setupUI();
    if (isEdit) {
        existingId = dokter->id;
        inputNama->setText(dokter->nama);
        inputSpesialisasi->setText(dokter->spesialisasi);
        inputTelepon->setText(dokter->noTelepon);
        inputJadwal->setText(dokter->jadwal);
        comboTersedia->setCurrentIndex(dokter->tersedia ? 0 : 1);
    }
}

void DialogDokter::setupUI()
{
    QVBoxLayout *lay = new QVBoxLayout(this);
    lay->setContentsMargins(20,20,20,20);
    lay->setSpacing(12);

    QLabel *title = new QLabel(isEdit ? "✏️  Edit Data Dokter" : "➕  Tambah Dokter Baru");
    title->setStyleSheet("color: #38bdf8; font-size: 16px; font-weight: 700;");
    lay->addWidget(title);

    QFrame *div = new QFrame; div->setFrameShape(QFrame::HLine);
    div->setStyleSheet("color: #1e293b; margin: 2px 0 8px 0;");
    lay->addWidget(div);

    auto lbl = [](const QString &t) {
        QLabel *l = new QLabel(t);
        l->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight:600;");
        return l;
    };

    QFormLayout *form = new QFormLayout;
    form->setSpacing(10);
    form->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);

    inputNama         = new QLineEdit; inputNama->setMinimumHeight(34);
    inputSpesialisasi = new QLineEdit; inputSpesialisasi->setMinimumHeight(34);
    inputTelepon      = new QLineEdit; inputTelepon->setMinimumHeight(34);
    inputJadwal       = new QLineEdit; inputJadwal->setMinimumHeight(34);
    comboTersedia     = new QComboBox; comboTersedia->addItems({"Tersedia","Tidak Tersedia"}); comboTersedia->setMinimumHeight(34);

    form->addRow(lbl("Nama Dokter :"),    inputNama);
    form->addRow(lbl("Spesialisasi :"),   inputSpesialisasi);
    form->addRow(lbl("No. Telepon :"),    inputTelepon);
    form->addRow(lbl("Jadwal Praktik :"), inputJadwal);
    form->addRow(lbl("Status :"),         comboTersedia);
    lay->addLayout(form);

    QHBoxLayout *btnRow = new QHBoxLayout;
    btnRow->addStretch();
    QPushButton *btnBatal  = new QPushButton("Batal");
    QPushButton *btnSimpan = new QPushButton(isEdit ? "💾  Simpan" : "➕  Tambahkan");
    btnBatal->setStyleSheet(
        "QPushButton { background-color: #334155; color: #e2e8f0; border: none; "
        "border-radius: 8px; padding: 9px 20px; font-size: 13px; }"
        "QPushButton:hover { background-color: #475569; }");
    btnSimpan->setStyleSheet(STYLE_BTN_PRIMARY);
    btnBatal->setMinimumHeight(36); btnSimpan->setMinimumHeight(36);
    btnBatal->setCursor(Qt::PointingHandCursor); btnSimpan->setCursor(Qt::PointingHandCursor);

    connect(btnBatal,  &QPushButton::clicked, this, &QDialog::reject);
    connect(btnSimpan, &QPushButton::clicked, this, [this](){
        if (inputNama->text().trimmed().isEmpty()) {
            QMessageBox::warning(this,"Peringatan","Nama dokter tidak boleh kosong!");
            return;
        }
        accept();
    });
    btnRow->addWidget(btnBatal);
    btnRow->addWidget(btnSimpan);
    lay->addLayout(btnRow);
}

Dokter DialogDokter::getDokter() const
{
    Dokter d;
    d.id           = existingId;
    d.nama         = inputNama->text().trimmed();
    d.spesialisasi = inputSpesialisasi->text().trimmed();
    d.noTelepon    = inputTelepon->text().trimmed();
    d.jadwal       = inputJadwal->text().trimmed();
    d.tersedia     = comboTersedia->currentIndex() == 0;
    return d;
}

// ============================================================
//  DIALOG OBAT
// ============================================================

DialogObat::DialogObat(QWidget *parent, Obat *obat)
    : QDialog(parent), isEdit(obat != nullptr), existingId(0)
{
    setStyleSheet(STYLE_DIALOG + STYLE_INPUT);
    setWindowTitle(isEdit ? "Edit Data Obat" : "Tambah Obat Baru");
    setMinimumWidth(400);
    setupUI();
    if (isEdit) {
        existingId = obat->id;
        inputNama->setText(obat->nama);
        inputJenis->setText(obat->jenis);
        spinStok->setValue(obat->stok);
        inputSatuan->setText(obat->satuan);
        inputHarga->setText(QString::number(obat->harga,'f',0));
    }
}

void DialogObat::setupUI()
{
    QVBoxLayout *lay = new QVBoxLayout(this);
    lay->setContentsMargins(20,20,20,20);
    lay->setSpacing(12);

    QLabel *title = new QLabel(isEdit ? "✏️  Edit Data Obat" : "➕  Tambah Obat Baru");
    title->setStyleSheet("color: #38bdf8; font-size: 16px; font-weight: 700;");
    lay->addWidget(title);

    QFrame *div = new QFrame; div->setFrameShape(QFrame::HLine);
    div->setStyleSheet("color: #1e293b; margin: 2px 0 8px 0;");
    lay->addWidget(div);

    auto lbl = [](const QString &t) {
        QLabel *l = new QLabel(t);
        l->setStyleSheet("color: #94a3b8; font-size: 12px; font-weight:600;");
        return l;
    };

    QFormLayout *form = new QFormLayout;
    form->setSpacing(10);
    form->setLabelAlignment(Qt::AlignRight | Qt::AlignVCenter);

    inputNama  = new QLineEdit; inputNama->setMinimumHeight(34);
    inputJenis = new QLineEdit; inputJenis->setMinimumHeight(34);
    spinStok   = new QSpinBox; spinStok->setRange(0,99999); spinStok->setMinimumHeight(34);
    inputSatuan= new QLineEdit; inputSatuan->setMinimumHeight(34);
    inputHarga = new QLineEdit; inputHarga->setPlaceholderText("Contoh: 2500"); inputHarga->setMinimumHeight(34);

    form->addRow(lbl("Nama Obat :"), inputNama);
    form->addRow(lbl("Jenis :"),     inputJenis);
    form->addRow(lbl("Stok :"),      spinStok);
    form->addRow(lbl("Satuan :"),    inputSatuan);
    form->addRow(lbl("Harga (Rp):"), inputHarga);
    lay->addLayout(form);

    QHBoxLayout *btnRow = new QHBoxLayout;
    btnRow->addStretch();
    QPushButton *btnBatal  = new QPushButton("Batal");
    QPushButton *btnSimpan = new QPushButton(isEdit ? "💾  Simpan" : "➕  Tambahkan");
    btnBatal->setStyleSheet(
        "QPushButton { background-color: #334155; color: #e2e8f0; border: none; "
        "border-radius: 8px; padding: 9px 20px; font-size: 13px; }"
        "QPushButton:hover { background-color: #475569; }");
    btnSimpan->setStyleSheet(STYLE_BTN_PRIMARY);
    btnBatal->setMinimumHeight(36); btnSimpan->setMinimumHeight(36);
    btnBatal->setCursor(Qt::PointingHandCursor); btnSimpan->setCursor(Qt::PointingHandCursor);

    connect(btnBatal,  &QPushButton::clicked, this, &QDialog::reject);
    connect(btnSimpan, &QPushButton::clicked, this, [this](){
        if (inputNama->text().trimmed().isEmpty()) {
            QMessageBox::warning(this,"Peringatan","Nama obat tidak boleh kosong!");
            return;
        }
        accept();
    });
    btnRow->addWidget(btnBatal);
    btnRow->addWidget(btnSimpan);
    lay->addLayout(btnRow);
}

Obat DialogObat::getObat() const
{
    Obat o;
    o.id    = existingId;
    o.nama  = inputNama->text().trimmed();
    o.jenis = inputJenis->text().trimmed();
    o.stok  = spinStok->value();
    o.satuan= inputSatuan->text().trimmed();
    o.harga = inputHarga->text().toDouble();
    return o;
}