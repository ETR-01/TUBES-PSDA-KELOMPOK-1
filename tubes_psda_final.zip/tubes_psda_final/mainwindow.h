#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QTableWidget>
#include <QComboBox>
#include <QDateEdit>
#include <QSpinBox>
#include <QTextEdit>
#include <QFrame>
#include <QStackedWidget>
#include <QMessageBox>
#include <QHeaderView>
#include <QScrollArea>
#include <QGroupBox>
#include <QStatusBar>
#include <QDialog>
#include <QFormLayout>
#include <QVector>
#include <QString>
#include <QDate>
#include <QTimer>
#include <QDateTime>
#include <QFont>
#include <QPalette>
#include <QPixmap>
#include <QIcon>
#include <QSizePolicy>
#include <QSpacerItem>
#include <QTabWidget>
#include <QListWidget>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QCheckBox>
#include <QRadioButton>
#include <QButtonGroup>
#include <QGraphicsDropShadowEffect>

// ============================================================
// ENUM: Role pengguna yang sedang login
// ============================================================
enum class RoleLogin {
    Admin,  // Bisa CRUD semua data
    User    // Hanya bisa melihat (Read-only)
};

// ============================================================
// DATA STRUCTURES — disimpan menggunakan QVector (Array)
// ============================================================

/**
 * @brief Struct Pasien — menyimpan data satu pasien rumah sakit
 */
struct Pasien {
    int     id;
    QString nama;
    QString jenisKelamin;   // "Laki-laki" / "Perempuan"
    int     umur;
    QDate   tanggalLahir;   // Tanggal lahir pasien (digunakan sebagai password login user)
    QString noTelepon;
    QString alamat;
    QString golonganDarah;
    QString diagnosa;
    QString dokter;
    QString ruangan;
    QDate   tanggalMasuk;
    QString status;         // "Rawat Inap" / "Rawat Jalan" / "Selesai"
};

/**
 * @brief Struct Dokter — menyimpan data satu dokter
 */
struct Dokter {
    int     id;
    QString nama;
    QString spesialisasi;
    QString noTelepon;
    QString jadwal;
    bool    tersedia;
};

/**
 * @brief Struct Obat — menyimpan data satu jenis obat
 */
struct Obat {
    int     id;
    QString nama;
    QString jenis;
    int     stok;
    QString satuan;
    double  harga;
};

/**
 * @brief Struct AkunUser — data akun pengguna (role User, bukan Admin)
 *        Kunci masuk: nama (sebagai username) + tanggal lahir
 *        Data bersumber dari dataPasien yang disimpan di JSON.
 */
struct AkunUser {
    QString username;       // Nama pasien (lowercase, tanpa spasi) atau nama lengkap
    QDate   tanggalLahir;   // Dijadikan sebagai "password" untuk user
    QString namaLengkap;
};

// ============================================================
// HALAMAN LOGIN — Window pertama yang tampil
// ============================================================

/**
 * @brief LoginWindow — Jendela login dengan dua opsi:
 *        1. Login sebagai User   → username + tanggal lahir
 *        2. Login sebagai Admin  → username universal + password universal
 *
 *  Credentials Admin (universal):
 *      Username : admin
 *      Password : admin123
 */
class LoginWindow : public QWidget
{
    Q_OBJECT

public:
    explicit LoginWindow(QWidget *parent = nullptr);

signals:
    // Dikirim ketika login berhasil, membawa role dan nama pengguna
    void loginBerhasil(RoleLogin role, const QString &namaUser);

private slots:
    void prosesLoginAdmin();    // Validasi kredensial admin
    void prosesLoginUser();     // Validasi username + tanggal lahir user
    void gantiBtnLogin();       // Ganti tampilan form sesuai pilihan radio

private:
    void setupUI();
    void setupFormAdmin();
    void setupFormUser();

    // Membaca data pasien dari file JSON yang disimpan MainWindow
    // dan mengubahnya menjadi daftar AkunUser untuk validasi login
    QVector<AkunUser> bacaAkunUserDariJSON() const;
    static QString    pathDataFile();   // Path file JSON (sama dengan MainWindow)

    // ---- Widget utama ----
    QStackedWidget  *stackForm;     // Berganti antara form admin / user
    QWidget         *formAdmin;
    QWidget         *formUser;

    // Form Admin
    QLineEdit       *inputAdminUsername;
    QLineEdit       *inputAdminPassword;

    // Form User
    QLineEdit       *inputUserUsername;
    QDateEdit       *inputUserTanggalLahir;

    // Pilihan role (radio button)
    QRadioButton    *radioAdmin;
    QRadioButton    *radioUser;

    // Kredensial admin universal (hardcoded)
    const QString ADMIN_USERNAME = "admin";
    const QString ADMIN_PASSWORD = "admin123";
};

// ============================================================
// MAIN WINDOW — Tampil setelah login berhasil
// ============================================================

/**
 * @brief MainWindow — Jendela utama aplikasi SI Rumah Sakit.
 *        Menampilkan halaman berbeda tergantung role:
 *        - Admin : bisa akses CRUD semua data
 *        - User  : hanya bisa melihat data (tombol tambah/edit/hapus disembunyikan)
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    /**
     * @param role      Role yang login (Admin atau User)
     * @param namaUser  Nama pengguna yang ditampilkan di sidebar
     * @param parent    Parent widget
     */
    explicit MainWindow(RoleLogin role, const QString &namaUser, QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Navigasi antar halaman
    void showDashboard();
    void showPasienPage();
    void showDokterPage();
    void showObatPage();
    void showCariPage();
    void prosesLogout();        // Kembali ke halaman login

    // Pasien CRUD (hanya bisa diakses Admin)
    void tambahPasien();
    void editPasien();
    void hapusPasien();
    void refreshTabelPasien();

    // Dokter CRUD (hanya bisa diakses Admin)
    void tambahDokter();
    void editDokter();
    void hapusDokter();
    void refreshTabelDokter();

    // Obat CRUD (hanya bisa diakses Admin)
    void tambahObat();
    void editObat();
    void hapusObat();
    void refreshTabelObat();

    // Linear Search
    void cariPasien();
    void cariDokter();
    void cariObat();
    void onSearchTypeChanged(int index);

    // Dashboard & Clock
    void updateDashboard();
    void updateClock();

private:
    // ---- Setup UI ----
    void setupUI();
    void setupSidebar();
    void setupDashboardPage();
    void setupPasienPage();
    void setupDokterPage();
    void setupObatPage();
    void setupCariPage();

    // ---- Helper ----
    QWidget*     createStatCard(const QString &title, const QString &value,
                            const QString &icon, const QString &color);
    QPushButton* createNavButton(const QString &text, const QString &icon);
    void         applyTableStyle(QTableWidget *table);
    void         setActiveNavButton(QPushButton *btn);
    void         inisialisasiDataContoh();

    // ---- Linear Search Algorithm ----
    QVector<int> linearSearchPasien(const QString &keyword, const QString &field);
    QVector<int> linearSearchDokter(const QString &keyword, const QString &field);
    QVector<int> linearSearchObat  (const QString &keyword, const QString &field);

    // ---- Persistensi Data (JSON) ----
    void    simpanData();
    void    muatData();
    QString pathDataFile() const;

    // ---- Widgets ----
    QWidget       *centralWidget;
    QHBoxLayout   *mainLayout;

    // Sidebar
    QWidget       *sidebar;
    QVBoxLayout   *sidebarLayout;
    QPushButton   *btnDashboard;
    QPushButton   *btnPasien;
    QPushButton   *btnDokter;
    QPushButton   *btnObat;
    QPushButton   *btnCari;
    QPushButton   *btnLogout;
    QPushButton   *activeNavBtn;
    QLabel        *lblInfoUser;     // Menampilkan nama & role yang login

    // Stacked pages
    QStackedWidget *stackedWidget;
    QWidget        *pageDashboard;
    QWidget        *pagePasien;
    QWidget        *pageDokter;
    QWidget        *pageObat;
    QWidget        *pageCari;

    // Dashboard widgets
    QLabel         *lblJamTanggal;
    QLabel         *lblTotalPasien;
    QLabel         *lblPasienRawatInap;
    QLabel         *lblPasienRawatJalan;
    QLabel         *lblTotalDokter;
    QLabel         *lblTotalObat;

    // Pasien widgets
    QTableWidget   *tabelPasien;
    QLineEdit      *inputCariPasienPage;

    // Dokter widgets
    QTableWidget   *tabelDokter;
    QLineEdit      *inputCariDokterPage;

    // Obat widgets
    QTableWidget   *tabelObat;
    QLineEdit      *inputCariObatPage;

    // Cari (Search) widgets
    QComboBox      *comboSearchType;
    QComboBox      *comboSearchField;
    QLineEdit      *inputSearchKeyword;
    QTableWidget   *tabelHasilCari;
    QLabel         *lblHasilInfo;
    QLabel         *lblStepInfo;

    // Data — disimpan sebagai array (QVector)
    QVector<Pasien> dataPasien;
    QVector<Dokter> dataDokter;
    QVector<Obat>   dataObat;
    int             nextPasienId;
    int             nextDokterId;
    int             nextObatId;

    // Timer untuk jam di dashboard
    QTimer         *clockTimer;

    // Role pengguna yang sedang login
    RoleLogin       roleAktif;
    QString         namaUserAktif;
};

// ============================================================
// DIALOG: Tambah / Edit Pasien
// ============================================================
class DialogPasien : public QDialog
{
    Q_OBJECT
public:
    explicit DialogPasien(QWidget *parent = nullptr, Pasien *pasien = nullptr);
    Pasien getPasien() const;

private:
    void setupUI();
    void populateFields(const Pasien &p);

    QLineEdit  *inputNama;
    QComboBox  *comboJK;
    QSpinBox   *spinUmur;
    QDateEdit  *inputTanggalLahir;
    QLineEdit  *inputTelepon;
    QLineEdit  *inputAlamat;
    QComboBox  *comboGoldar;
    QLineEdit  *inputDiagnosa;
    QLineEdit  *inputDokter;
    QLineEdit  *inputRuangan;
    QDateEdit  *inputTanggal;
    QComboBox  *comboStatus;

    bool       isEdit;
    int        existingId;
    QDate      existingTanggal;
};

// ============================================================
// DIALOG: Tambah / Edit Dokter
// ============================================================
class DialogDokter : public QDialog
{
    Q_OBJECT
public:
    explicit DialogDokter(QWidget *parent = nullptr, Dokter *dokter = nullptr);
    Dokter getDokter() const;

private:
    void setupUI();

    QLineEdit  *inputNama;
    QLineEdit  *inputSpesialisasi;
    QLineEdit  *inputTelepon;
    QLineEdit  *inputJadwal;
    QComboBox  *comboTersedia;

    bool       isEdit;
    int        existingId;
};

// ============================================================
// DIALOG: Tambah / Edit Obat
// ============================================================
class DialogObat : public QDialog
{
    Q_OBJECT
public:
    explicit DialogObat(QWidget *parent = nullptr, Obat *obat = nullptr);
    Obat getObat() const;

private:
    void setupUI();

    QLineEdit  *inputNama;
    QLineEdit  *inputJenis;
    QSpinBox   *spinStok;
    QLineEdit  *inputSatuan;
    QLineEdit  *inputHarga;

    bool       isEdit;
    int        existingId;
};

#endif // MAINWINDOW_H